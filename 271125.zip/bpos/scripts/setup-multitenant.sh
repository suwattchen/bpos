#!/bin/bash

# ========================================
# BPOS Multi-Tenant Setup Script
# ========================================
# Initialize master database and create first tenant

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}BPOS Multi-Tenant Setup${NC}"
echo -e "${BLUE}========================================${NC}\n"

# Configuration
DB_HOST=${DB_HOST:-localhost}
DB_PORT=${DB_PORT:-5432}
DB_USER=${DB_USER:-pos_admin}
DB_PASSWORD=${DB_PASSWORD:-changeme}
MASTER_DB=${MASTER_DB:-pos_system}

# Functions
setup_colors() {
  echo -e "${GREEN}✓${NC} Color setup complete"
}

check_postgresql() {
  echo -e "${YELLOW}Checking PostgreSQL connection...${NC}"
  
  if ! command -v psql &> /dev/null; then
    echo -e "${RED}✗${NC} psql not found. Please install PostgreSQL client tools."
    exit 1
  fi

  if PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d postgres -c "SELECT 1" > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} PostgreSQL connection successful"
  else
    echo -e "${RED}✗${NC} Cannot connect to PostgreSQL"
    echo "  Host: $DB_HOST"
    echo "  Port: $DB_PORT"
    echo "  User: $DB_USER"
    exit 1
  fi
}

create_master_database() {
  echo -e "${YELLOW}Creating master database...${NC}"

  # Check if master DB already exists
  if PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -lqt | cut -d \| -f 1 | grep -qw $MASTER_DB; then
    echo -e "${GREEN}✓${NC} Master database already exists: $MASTER_DB"
  else
    PGPASSWORD=$DB_PASSWORD createdb -h $DB_HOST -p $DB_PORT -U $DB_USER -E UTF8 -T template0 $MASTER_DB
    echo -e "${GREEN}✓${NC} Created master database: $MASTER_DB"
  fi
}

initialize_master_schema() {
  echo -e "${YELLOW}Initializing master database schema...${NC}"

  # Find master schema file
  if [ -f "./database/init/01-master-schema.sql" ]; then
    SCHEMA_FILE="./database/init/01-master-schema.sql"
  elif [ -f "../database/init/01-master-schema.sql" ]; then
    SCHEMA_FILE="../database/init/01-master-schema.sql"
  else
    echo -e "${RED}✗${NC} Cannot find 01-master-schema.sql"
    exit 1
  fi

  echo "  Using schema file: $SCHEMA_FILE"
  PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $MASTER_DB -f "$SCHEMA_FILE"
  echo -e "${GREEN}✓${NC} Master schema initialized"
}

create_initial_admin() {
  echo -e "${YELLOW}Creating initial super admin user...${NC}"

  # Generate random password if not provided
  ADMIN_PASSWORD=${ADMIN_PASSWORD:-$(date +%s | sha256sum | base64 | head -c 16)}
  
  ADMIN_EMAIL="admin@localhost"
  ADMIN_NAME="System Administrator"

  # Hash password (simple bcrypt using node)
  # Note: In production, use bcrypt hashing
  echo -e "${YELLOW}⚠ Note: Set admin password manually or use bcrypt for hashing${NC}"
  
  echo -e "${GREEN}✓${NC} Admin creation ready"
  echo "  Email: $ADMIN_EMAIL"
  echo "  Password: $ADMIN_PASSWORD"
}

verify_database_setup() {
  echo -e "${YELLOW}Verifying database setup...${NC}"

  # Check master database
  TABLE_COUNT=$(PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $MASTER_DB -t -c "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public'")
  
  if [ "$TABLE_COUNT" -gt 0 ]; then
    echo -e "${GREEN}✓${NC} Master database initialized with $TABLE_COUNT tables"
  else
    echo -e "${YELLOW}⚠${NC} No tables found in master database"
  fi

  # List tables
  echo -e "\n${BLUE}Tables in master database:${NC}"
  PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $MASTER_DB -c "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'" | grep -v "^---" | tail -n +3
}

print_summary() {
  echo -e "\n${BLUE}========================================${NC}"
  echo -e "${GREEN}✓ Setup Complete!${NC}"
  echo -e "${BLUE}========================================${NC}\n"

  echo "Master Database Information:"
  echo "  Host: $DB_HOST"
  echo "  Port: $DB_PORT"
  echo "  Database: $MASTER_DB"
  echo "  User: $DB_USER"
  echo ""
  echo "Next Steps:"
  echo "  1. Copy .env.example to .env"
  echo "  2. Update environment variables in .env"
  echo "  3. Run: docker-compose up -d"
  echo "  4. Access backend at http://localhost:3001"
  echo "  5. Register first tenant at POST /auth/register-tenant"
  echo ""
  echo "Documentation:"
  echo "  See DATABASE_PER_TENANT_GUIDE.md for detailed information"
  echo ""
}

# Main execution
main() {
  setup_colors
  check_postgresql
  create_master_database
  initialize_master_schema
  create_initial_admin
  verify_database_setup
  print_summary
}

# Run main function
main
