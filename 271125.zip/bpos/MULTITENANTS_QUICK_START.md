# 🚀 Quick Start - Database-Per-Tenant Setup

**Status:** Ready to test ✅

## Prerequisites

- Docker & Docker Compose
- Node.js 18+
- PostgreSQL client (psql)
- Git

## Step 1: Prepare Environment

```bash
# Navigate to project
cd /home/tcnb/Documents/projects/bpos/bpos

# Copy environment template
cp .env.example .env

# Review and update .env (critical settings):
# - JWT_SECRET: Change to a secure value
# - DB_PASSWORD: Change to secure password
# - MINIO_SECRET_KEY: Change to secure value
```

## Step 2: Start Services

```bash
# From bpos/bpos directory
docker-compose up -d --build

# Wait for all services to be healthy (30-60 seconds)
docker-compose ps

# Check logs
docker-compose logs postgres
docker-compose logs backend
```

## Step 3: Initialize Master Database (Run ONCE)

```bash
# Make script executable
chmod +x scripts/setup-multitenant.sh

# Run setup script
DB_HOST=localhost \
DB_PORT=5433 \
DB_USER=pos_admin \
DB_PASSWORD=changeme \
./scripts/setup-multitenant.sh

# If using Docker network:
DB_HOST=postgres \
DB_PORT=5432 \
./scripts/setup-multitenant.sh
```

## Step 4: Register First Tenant

```bash
curl -X POST http://localhost:3001/auth/register-tenant \
  -H "Content-Type: application/json" \
  -d '{
    "email": "owner@shop1.com",
    "password": "SecurePass123!",
    "tenant_name": "Coffee Shop #1",
    "owner_name": "John Doe",
    "phone": "+66812345678"
  }'

# Save the returned token!
# Response example:
# {
#   "success": true,
#   "data": {
#     "tenant": {"id": "abc123...", "name": "Coffee Shop #1"},
#     "user": {"id": "def456...", "email": "owner@shop1.com", "role": "owner"},
#     "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
#   }
# }
```

## Step 5: Test Authenticated Request

```bash
# Replace TOKEN with actual token from Step 4
TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

# Get products (should be empty for new tenant)
curl -X GET http://localhost:3001/api/products \
  -H "Authorization: Bearer $TOKEN"

# Create a product
curl -X POST http://localhost:3001/api/products \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "sku": "COFFEE-001",
    "name": "Espresso",
    "selling_price": 45.00,
    "tax_rate": 7.0
  }'

# Create another tenant
curl -X POST http://localhost:3001/auth/register-tenant \
  -H "Content-Type: application/json" \
  -d '{
    "email": "owner@shop2.com",
    "password": "SecurePass456!",
    "tenant_name": "Pizza Place #2",
    "owner_name": "Jane Smith"
  }'

# Verify isolation: Shop2's products don't see Shop1's product
# Use Shop2's token - should see empty products list
```

## Step 6: Verify Database Isolation

```bash
# Connect to PostgreSQL
psql -h localhost -p 5433 -U pos_admin -d pos_system

# List all tenant databases
\l | grep tenant_

# List all database users
\du | grep tenant_

# Check master database tables
\dt

# Exit
\q
```

## Step 7: Monitor & Verify

```bash
# Backend logs
docker-compose logs -f backend

# Database logs
docker-compose logs -f postgres

# Health check
curl http://localhost:3001/health

# Verify token
TOKEN="your_token_here"
curl -X GET http://localhost:3001/auth/verify \
  -H "Authorization: Bearer $TOKEN"
```

## Common Commands

### Restart Services

```bash
# Restart backend (after code changes)
docker-compose restart backend

# Rebuild and restart
docker-compose up -d --build backend

# Full restart (dangerous - loses data)
docker-compose down && docker-compose up -d
```

### View Logs

```bash
# All services
docker-compose logs

# Specific service with tail
docker-compose logs -f backend

# Last 50 lines
docker-compose logs --tail=50 backend
```

### Direct Database Access

```bash
# Connect as admin
psql -h localhost -p 5433 -U pos_admin -d pos_system

# Connect as tenant
psql -h localhost -p 5433 -U tenant_abc123 -d tenant_abc123

# Inside Docker
docker-compose exec postgres psql -U pos_admin -d pos_system
```

### Cleanup

```bash
# Stop all services
docker-compose down

# Stop and remove volumes (WARNING: deletes all data)
docker-compose down -v

# Remove specific container
docker-compose rm -f backend
```

## Troubleshooting

### Connection Refused

```bash
# Check if Docker services are running
docker-compose ps

# Check if port 5433 is in use
lsof -i :5433

# Start services again
docker-compose up -d
```

### Master Database Not Initialized

```bash
# Check if schema was applied
docker-compose exec postgres psql -U pos_admin -d pos_system -c "\dt"

# Re-run setup script
./scripts/setup-multitenant.sh

# Or manually apply schema
docker-compose exec postgres psql -U pos_admin -d pos_system < database/init/01-master-schema.sql
```

### Tenant Database Creation Failed

```bash
# Check backend logs
docker-compose logs backend

# Check if user/database was created
docker-compose exec postgres psql -U pos_admin -d pos_system -c "SELECT * FROM tenant_databases;"

# Check PostgreSQL max connections
docker-compose exec postgres psql -U pos_admin -d postgres -c "SHOW max_connections;"

# Increase if needed (update docker-compose.yml)
```

### Token Expired / Invalid

```bash
# Refresh token
curl -X POST http://localhost:3001/auth/refresh \
  -H "Authorization: Bearer $TOKEN"

# Or re-login
curl -X POST http://localhost:3001/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "owner@shop1.com",
    "password": "SecurePass123!"
  }'
```

## What to Test

✅ **Registration**
- [ ] Register 2 different tenants
- [ ] Verify different databases created
- [ ] Tokens differ between tenants

✅ **Isolation**
- [ ] Tenant 1 creates products - Tenant 2 can't see them
- [ ] Tenant 2 creates customers - Tenant 1 can't see them
- [ ] Data is completely isolated

✅ **Authentication**
- [ ] Valid token works
- [ ] Invalid token rejected (401)
- [ ] Expired token rejected (use JWT exp time)
- [ ] Token refresh works

✅ **Scaling**
- [ ] Create 5+ tenants
- [ ] Each has own database
- [ ] Performance remains good
- [ ] No connection pool exhaustion

## Next: Read Full Documentation

See `DATABASE_PER_TENANT_GUIDE.md` for:
- Architecture details
- API documentation
- Deployment guide
- Troubleshooting
- Backup procedures

---

**Status:** ✅ Ready to test  
**Last Updated:** November 26, 2025
