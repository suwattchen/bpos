-- ========================================
-- Tenant Database Schema
-- ========================================
-- This schema is created per tenant (database-per-tenant strategy)
-- No need for tenant_id filtering since each DB is isolated

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ========================================
-- 1. TENANT METADATA TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  settings jsonb DEFAULT '{}'::jsonb,
  subscription_status text DEFAULT 'active' CHECK (subscription_status IN ('active', 'suspended', 'cancelled')),
  subscription_plan text DEFAULT 'basic' CHECK (subscription_plan IN ('basic', 'professional', 'enterprise')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_tenants_slug ON tenants(slug);
CREATE INDEX idx_tenants_status ON tenants(subscription_status);

-- ========================================
-- 2. TENANT USERS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS tenant_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  encrypted_password text NOT NULL,
  full_name text,
  phone text,
  role text NOT NULL CHECK (role IN ('owner', 'manager', 'cashier', 'viewer')),
  is_active boolean DEFAULT true,
  last_login timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_tenant_users_email ON tenant_users(email);
CREATE INDEX idx_tenant_users_role ON tenant_users(role);
CREATE INDEX idx_tenant_users_active ON tenant_users(is_active) WHERE is_active = true;

-- ========================================
-- 3. CATEGORIES TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  image_url text,
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  parent_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_categories_slug ON categories(slug);
CREATE INDEX idx_categories_parent ON categories(parent_id);
CREATE INDEX idx_categories_active ON categories(is_active) WHERE is_active = true;

-- ========================================
-- 4. PRODUCTS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  sku text NOT NULL UNIQUE,
  barcode text UNIQUE,
  name text NOT NULL,
  description text DEFAULT '',
  image_url text,
  cost_price decimal(10,2) DEFAULT 0,
  selling_price decimal(10,2) NOT NULL,
  tax_rate decimal(5,2) DEFAULT 7,
  is_active boolean DEFAULT true,
  is_variant boolean DEFAULT false,
  variant_parent_id uuid REFERENCES products(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_products_sku ON products(sku);
CREATE INDEX idx_products_barcode ON products(barcode) WHERE barcode IS NOT NULL;
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_active ON products(is_active) WHERE is_active = true;
CREATE INDEX idx_products_name_search ON products USING GIN(name gin_trgm_ops);

-- ========================================
-- 5. INVENTORY TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL UNIQUE REFERENCES products(id) ON DELETE CASCADE,
  quantity integer DEFAULT 0,
  reorder_level integer DEFAULT 10,
  reorder_quantity integer DEFAULT 50,
  last_counted_at timestamptz,
  last_updated timestamptz DEFAULT now()
);

CREATE INDEX idx_inventory_product ON inventory(product_id);
CREATE INDEX idx_inventory_low_stock ON inventory(product_id) WHERE quantity <= reorder_level;

-- ========================================
-- 6. STOCK MOVEMENTS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  movement_type text NOT NULL CHECK (movement_type IN ('in', 'out', 'adjustment', 'return')),
  quantity integer NOT NULL,
  reference_id text, -- transaction_id or reference
  notes text,
  created_by uuid REFERENCES tenant_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_stock_movements_product ON stock_movements(product_id);
CREATE INDEX idx_stock_movements_type ON stock_movements(movement_type);
CREATE INDEX idx_stock_movements_date ON stock_movements(created_at DESC);

-- ========================================
-- 7. CUSTOMERS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_code text NOT NULL UNIQUE,
  name text NOT NULL,
  email text,
  phone text UNIQUE,
  address text,
  city text,
  postal_code text,
  loyalty_points integer DEFAULT 0,
  total_purchases decimal(10,2) DEFAULT 0,
  total_spent decimal(10,2) DEFAULT 0,
  is_active boolean DEFAULT true,
  first_purchase_at timestamptz,
  last_purchase_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_customers_code ON customers(customer_code);
CREATE INDEX idx_customers_phone ON customers(phone) WHERE phone IS NOT NULL;
CREATE INDEX idx_customers_active ON customers(is_active) WHERE is_active = true;
CREATE INDEX idx_customers_name_search ON customers USING GIN(name gin_trgm_ops);

-- ========================================
-- 8. TRANSACTIONS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_number text NOT NULL UNIQUE,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  cashier_id uuid REFERENCES tenant_users(id) ON DELETE SET NULL,
  subtotal decimal(10,2) NOT NULL,
  tax_amount decimal(10,2) DEFAULT 0,
  discount_amount decimal(10,2) DEFAULT 0,
  total_amount decimal(10,2) NOT NULL,
  payment_method text NOT NULL CHECK (payment_method IN ('cash', 'card', 'cheque', 'online', 'other')),
  payment_status text DEFAULT 'completed' CHECK (payment_status IN ('pending', 'completed', 'failed', 'refunded')),
  notes text,
  status text DEFAULT 'completed' CHECK (status IN ('draft', 'completed', 'refunded', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_transactions_number ON transactions(transaction_number);
CREATE INDEX idx_transactions_customer ON transactions(customer_id);
CREATE INDEX idx_transactions_cashier ON transactions(cashier_id);
CREATE INDEX idx_transactions_date ON transactions(created_at DESC);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_payment_method ON transactions(payment_method);

-- ========================================
-- 9. TRANSACTION ITEMS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS transaction_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  quantity integer NOT NULL,
  unit_price decimal(10,2) NOT NULL,
  tax_rate decimal(5,2) DEFAULT 0,
  discount_percent decimal(5,2) DEFAULT 0,
  subtotal decimal(10,2) NOT NULL,
  tax_amount decimal(10,2) DEFAULT 0,
  total_amount decimal(10,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_transaction_items_transaction ON transaction_items(transaction_id);
CREATE INDEX idx_transaction_items_product ON transaction_items(product_id);

-- ========================================
-- 10. VOUCHERS/DISCOUNTS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS vouchers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  description text,
  discount_type text NOT NULL CHECK (discount_type IN ('fixed', 'percentage')),
  discount_value decimal(10,2) NOT NULL,
  min_purchase_amount decimal(10,2) DEFAULT 0,
  max_usage_per_customer integer,
  max_total_usage integer,
  usage_count integer DEFAULT 0,
  is_active boolean DEFAULT true,
  valid_from timestamptz,
  valid_until timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_vouchers_code ON vouchers(code);
CREATE INDEX idx_vouchers_active ON vouchers(is_active) WHERE is_active = true;

-- ========================================
-- 11. AUDIT LOG TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES tenant_users(id) ON DELETE SET NULL,
  entity_type text NOT NULL, -- 'product', 'transaction', 'customer', etc.
  entity_id uuid,
  action text NOT NULL CHECK (action IN ('create', 'update', 'delete', 'view')),
  changes jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_date ON audit_logs(created_at DESC);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);

-- ========================================
-- 12. SETTINGS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  value jsonb,
  description text,
  updated_by uuid REFERENCES tenant_users(id) ON DELETE SET NULL,
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_settings_key ON settings(key);

-- ========================================
-- DEFAULT SETTINGS
-- ========================================
INSERT INTO settings (key, value, description) VALUES
  ('currency', '{"code": "THB", "symbol": "฿"}', 'Currency settings'),
  ('tax_enabled', 'true', 'Enable tax in transactions'),
  ('default_tax_rate', '7.0', 'Default tax rate percentage'),
  ('receipt_format', '{"width": 58, "font_size": 12}', 'Receipt printing format'),
  ('business_hours', '{"open": "09:00", "close": "21:00"}', 'Business operating hours'),
  ('loyalty_program', '{"enabled": true, "points_per_baht": 1, "points_value": 1}', 'Loyalty program settings')
ON CONFLICT (key) DO NOTHING;

-- ========================================
-- FUNCTIONS AND TRIGGERS
-- ========================================

-- Update timestamp function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for products
CREATE TRIGGER products_update_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger for categories
CREATE TRIGGER categories_update_updated_at
  BEFORE UPDATE ON categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger for customers
CREATE TRIGGER customers_update_updated_at
  BEFORE UPDATE ON customers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger for transactions
CREATE TRIGGER transactions_update_updated_at
  BEFORE UPDATE ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger for tenant_users
CREATE TRIGGER tenant_users_update_updated_at
  BEFORE UPDATE ON tenant_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to calculate transaction totals
CREATE OR REPLACE FUNCTION calculate_transaction_totals()
RETURNS TRIGGER AS $$
BEGIN
  -- Update transaction totals when items change
  UPDATE transactions
  SET 
    subtotal = (SELECT COALESCE(SUM(subtotal), 0) FROM transaction_items WHERE transaction_id = NEW.transaction_id),
    tax_amount = (SELECT COALESCE(SUM(tax_amount), 0) FROM transaction_items WHERE transaction_id = NEW.transaction_id),
    total_amount = (
      SELECT COALESCE(SUM(total_amount), 0) - COALESCE(NEW.transaction_id::decimal, 0)
      FROM transaction_items
      WHERE transaction_id = NEW.transaction_id
    )
  WHERE id = NEW.transaction_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for transaction items
CREATE TRIGGER transaction_items_calculate_totals
  AFTER INSERT OR UPDATE ON transaction_items
  FOR EACH ROW
  EXECUTE FUNCTION calculate_transaction_totals();

-- Function to update inventory on transaction
CREATE OR REPLACE FUNCTION update_inventory_on_transaction()
RETURNS TRIGGER AS $$
BEGIN
  -- Reduce inventory when transaction is completed
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    UPDATE inventory
    SET quantity = quantity - ti.quantity
    FROM transaction_items ti
    WHERE inventory.product_id = ti.product_id AND ti.transaction_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update inventory
CREATE TRIGGER transactions_update_inventory
  AFTER INSERT OR UPDATE ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_inventory_on_transaction();

-- ========================================
-- INITIAL DATA
-- ========================================

-- Insert default categories
INSERT INTO categories (name, slug, description, display_order) VALUES
  ('Beverages', 'beverages', 'Drinks and beverages', 1),
  ('Food', 'food', 'Food items', 2),
  ('Snacks', 'snacks', 'Snacks and sides', 3),
  ('Desserts', 'desserts', 'Desserts and sweets', 4)
ON CONFLICT (slug) DO NOTHING;

-- ========================================
-- VIEWS FOR COMMON QUERIES
-- ========================================

-- Daily sales summary
CREATE OR REPLACE VIEW daily_sales_summary AS
SELECT
  DATE(created_at) as sale_date,
  COUNT(*) as transaction_count,
  SUM(total_amount) as daily_total,
  SUM(tax_amount) as daily_tax,
  AVG(total_amount) as avg_transaction_value,
  COUNT(DISTINCT customer_id) as unique_customers
FROM transactions
WHERE status = 'completed'
GROUP BY DATE(created_at);

-- Low stock products
CREATE OR REPLACE VIEW low_stock_products AS
SELECT
  p.id,
  p.sku,
  p.name,
  i.quantity,
  i.reorder_level,
  c.name as category_name
FROM products p
JOIN inventory i ON p.id = i.product_id
JOIN categories c ON p.category_id = c.id
WHERE i.quantity <= i.reorder_level AND p.is_active = true;

-- Top selling products
CREATE OR REPLACE VIEW top_selling_products AS
SELECT
  p.id,
  p.name,
  p.sku,
  SUM(ti.quantity) as total_sold,
  SUM(ti.total_amount) as total_revenue
FROM products p
JOIN transaction_items ti ON p.id = ti.product_id
JOIN transactions t ON ti.transaction_id = t.id
WHERE t.status = 'completed'
GROUP BY p.id, p.name, p.sku
ORDER BY total_sold DESC;

-- Best customers
CREATE OR REPLACE VIEW best_customers AS
SELECT
  id,
  customer_code,
  name,
  email,
  phone,
  total_purchases,
  total_spent,
  loyalty_points,
  last_purchase_at
FROM customers
WHERE is_active = true
ORDER BY total_spent DESC;

-- ========================================
-- DATABASE COMPLETED
-- ========================================
