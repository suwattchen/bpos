-- ========================================
-- MASTER DATABASE SCHEMA
-- ========================================
-- This schema manages tenant metadata and connections
-- Shared across all tenants

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ========================================
-- 1. TENANT REGISTRY TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS tenant_databases (
  tenant_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  database_name text NOT NULL UNIQUE,
  username text NOT NULL UNIQUE,
  password text NOT NULL,
  host text NOT NULL,
  port integer NOT NULL DEFAULT 5432,
  status text DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'deleted')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_tenant_databases_status ON tenant_databases(status);
CREATE INDEX idx_tenant_databases_created ON tenant_databases(created_at DESC);

-- ========================================
-- 1.5 TENANT EMAILS TABLE (for quick lookup during login)
-- ========================================
CREATE TABLE IF NOT EXISTS tenant_emails (
  tenant_id uuid UNIQUE REFERENCES tenant_databases(tenant_id) ON DELETE CASCADE,
  email text PRIMARY KEY NOT NULL
);

CREATE INDEX idx_tenant_emails_tenant ON tenant_emails(tenant_id);

-- ========================================
-- 2. MASTER USERS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS master_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  encrypted_password text NOT NULL,
  full_name text,
  role text NOT NULL CHECK (role IN ('super_admin', 'admin', 'support')),
  is_active boolean DEFAULT true,
  last_login timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_master_users_email ON master_users(email);
CREATE INDEX idx_master_users_role ON master_users(role);

-- ========================================
-- 3. TENANT SUBSCRIPTIONS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS tenant_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL UNIQUE REFERENCES tenant_databases(tenant_id) ON DELETE CASCADE,
  plan_name text NOT NULL CHECK (plan_name IN ('basic', 'professional', 'enterprise')),
  status text DEFAULT 'active' CHECK (status IN ('trial', 'active', 'suspended', 'cancelled')),
  billing_cycle text DEFAULT 'monthly' CHECK (billing_cycle IN ('monthly', 'yearly')),
  amount decimal(10,2) NOT NULL,
  max_users integer DEFAULT 5,
  max_daily_transactions integer DEFAULT 1000,
  features jsonb DEFAULT '{"inventory": true, "reports": true, "customers": true}'::jsonb,
  started_at timestamptz DEFAULT now(),
  renews_at timestamptz,
  cancelled_at timestamptz,
  auto_renew boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_tenant_subscriptions_tenant ON tenant_subscriptions(tenant_id);
CREATE INDEX idx_tenant_subscriptions_status ON tenant_subscriptions(status);
CREATE INDEX idx_tenant_subscriptions_renews ON tenant_subscriptions(renews_at);

-- ========================================
-- 4. BILLING INVOICES TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS billing_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenant_databases(tenant_id) ON DELETE CASCADE,
  subscription_id uuid REFERENCES tenant_subscriptions(id) ON DELETE SET NULL,
  invoice_number text NOT NULL UNIQUE,
  amount decimal(10,2) NOT NULL,
  tax decimal(10,2) DEFAULT 0,
  total decimal(10,2) NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'overdue', 'cancelled')),
  billing_period_start date NOT NULL,
  billing_period_end date NOT NULL,
  due_date date NOT NULL,
  paid_at timestamptz,
  payment_method text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_billing_invoices_tenant ON billing_invoices(tenant_id);
CREATE INDEX idx_billing_invoices_status ON billing_invoices(status);
CREATE INDEX idx_billing_invoices_due_date ON billing_invoices(due_date);
CREATE INDEX idx_billing_invoices_number ON billing_invoices(invoice_number);

-- ========================================
-- 5. AUDIT LOG TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS master_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES master_users(id) ON DELETE SET NULL,
  action text NOT NULL, -- 'tenant_created', 'tenant_suspended', etc.
  tenant_id uuid REFERENCES tenant_databases(tenant_id) ON DELETE CASCADE,
  details jsonb,
  ip_address text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_master_audit_logs_user ON master_audit_logs(user_id);
CREATE INDEX idx_master_audit_logs_tenant ON master_audit_logs(tenant_id);
CREATE INDEX idx_master_audit_logs_action ON master_audit_logs(action);
CREATE INDEX idx_master_audit_logs_date ON master_audit_logs(created_at DESC);

-- ========================================
-- 6. SYSTEM SETTINGS TABLE
-- ========================================
CREATE TABLE IF NOT EXISTS master_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  value jsonb,
  description text,
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_master_settings_key ON master_settings(key);

-- ========================================
-- DEFAULT MASTER SETTINGS
-- ========================================
INSERT INTO master_settings (key, value, description) VALUES
  ('system_maintenance', 'false', 'System maintenance mode'),
  ('max_inactive_days', '30', 'Days before auto-suspending inactive tenants'),
  ('backup_enabled', 'true', 'Enable automatic backups'),
  ('backup_frequency', 'daily', 'Backup frequency (hourly, daily, weekly)'),
  ('email_notifications_enabled', 'true', 'Enable email notifications'),
  ('support_email', '{"address": "support@example.com", "name": "Support Team"}', 'Support contact email'),
  ('api_rate_limit', '{"requests": 1000, "window_seconds": 3600}', 'API rate limit settings')
ON CONFLICT (key) DO NOTHING;

-- ========================================
-- FUNCTIONS
-- ========================================

-- Function to create new tenant
CREATE OR REPLACE FUNCTION create_new_tenant(
  p_database_name text,
  p_username text,
  p_password text,
  p_plan_name text
)
RETURNS TABLE(tenant_id uuid, database_name text) AS $$
DECLARE
  v_tenant_id uuid;
BEGIN
  -- Generate tenant ID
  v_tenant_id := gen_random_uuid();

  -- Insert into tenant_databases
  INSERT INTO tenant_databases (tenant_id, database_name, username, password, host, port, status)
  VALUES (v_tenant_id, p_database_name, p_username, p_password, 'localhost', 5432, 'active');

  -- Insert subscription
  INSERT INTO tenant_subscriptions (tenant_id, plan_name, status)
  VALUES (v_tenant_id, p_plan_name, 'trial');

  -- Create audit log
  INSERT INTO master_audit_logs (action, tenant_id, details)
  VALUES ('tenant_created', v_tenant_id, jsonb_build_object(
    'database', p_database_name,
    'plan', p_plan_name
  ));

  RETURN QUERY SELECT v_tenant_id, p_database_name;
END;
$$ LANGUAGE plpgsql;

-- Function to suspend tenant
CREATE OR REPLACE FUNCTION suspend_tenant(p_tenant_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE tenant_databases
  SET status = 'suspended', updated_at = now()
  WHERE tenant_id = p_tenant_id;

  UPDATE tenant_subscriptions
  SET status = 'suspended', updated_at = now()
  WHERE tenant_id = p_tenant_id;

  INSERT INTO master_audit_logs (action, tenant_id)
  VALUES ('tenant_suspended', p_tenant_id);
END;
$$ LANGUAGE plpgsql;

-- Function to activate tenant
CREATE OR REPLACE FUNCTION activate_tenant(p_tenant_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE tenant_databases
  SET status = 'active', updated_at = now()
  WHERE tenant_id = p_tenant_id;

  UPDATE tenant_subscriptions
  SET status = 'active', updated_at = now()
  WHERE tenant_id = p_tenant_id;

  INSERT INTO master_audit_logs (action, tenant_id)
  VALUES ('tenant_activated', p_tenant_id);
END;
$$ LANGUAGE plpgsql;

-- ========================================
-- VIEWS
-- ========================================

-- All active tenants with subscription info
CREATE OR REPLACE VIEW active_tenants_view AS
SELECT
  td.tenant_id,
  td.database_name,
  td.status,
  ts.plan_name,
  ts.status as subscription_status,
  ts.started_at,
  ts.renews_at,
  td.created_at
FROM tenant_databases td
LEFT JOIN tenant_subscriptions ts ON td.tenant_id = ts.tenant_id
WHERE td.status = 'active';

-- Billing summary
CREATE OR REPLACE VIEW billing_summary_view AS
SELECT
  td.tenant_id,
  td.database_name,
  ts.plan_name,
  COUNT(CASE WHEN bi.status = 'paid' THEN 1 END) as paid_invoices,
  COUNT(CASE WHEN bi.status = 'pending' THEN 1 END) as pending_invoices,
  COUNT(CASE WHEN bi.status = 'overdue' THEN 1 END) as overdue_invoices,
  COALESCE(SUM(CASE WHEN bi.status = 'pending' THEN bi.total END), 0) as pending_amount,
  COALESCE(SUM(CASE WHEN bi.status = 'overdue' THEN bi.total END), 0) as overdue_amount
FROM tenant_databases td
LEFT JOIN tenant_subscriptions ts ON td.tenant_id = ts.tenant_id
LEFT JOIN billing_invoices bi ON td.tenant_id = bi.tenant_id
GROUP BY td.tenant_id, td.database_name, ts.plan_name;

-- ========================================
-- MASTER DATABASE COMPLETED
-- ========================================
