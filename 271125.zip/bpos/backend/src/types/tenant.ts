/**
 * Tenant-related TypeScript types
 */

/**
 * Tenant Metadata
 */
export interface Tenant {
  id: string;
  name: string;
  slug: string;
  settings?: Record<string, any>;
  subscription_status: 'active' | 'suspended' | 'cancelled';
  subscription_plan: 'basic' | 'professional' | 'enterprise';
  created_at: string;
  updated_at: string;
}

/**
 * Tenant User
 */
export interface TenantUser {
  id: string;
  email: string;
  full_name?: string;
  phone?: string;
  role: 'owner' | 'manager' | 'cashier' | 'viewer';
  is_active: boolean;
  last_login?: string;
  created_at: string;
  updated_at: string;
}

/**
 * Database Configuration for Tenant
 */
export interface TenantDatabaseConfig {
  tenant_id: string;
  name: string;
  user: string;
  password: string;
  host: string;
  port: number;
}

/**
 * Tenant Registration Request
 */
export interface RegisterTenantRequest {
  email: string;
  password: string;
  tenant_name: string;
  owner_name?: string;
  phone?: string;
}

/**
 * Login Request
 */
export interface LoginRequest {
  email: string;
  password: string;
}

/**
 * JWT Payload
 */
export interface JWTPayload {
  tenantId: string;
  userId: string;
  email: string;
  role: string;
  iat?: number;
  exp?: number;
}

/**
 * Tenant Subscription
 */
export interface TenantSubscription {
  id: string;
  tenant_id: string;
  plan_name: 'basic' | 'professional' | 'enterprise';
  status: 'trial' | 'active' | 'suspended' | 'cancelled';
  billing_cycle: 'monthly' | 'yearly';
  amount: number;
  max_users: number;
  max_daily_transactions: number;
  features: {
    inventory: boolean;
    reports: boolean;
    customers: boolean;
    [key: string]: boolean;
  };
  started_at: string;
  renews_at?: string;
  cancelled_at?: string;
  auto_renew: boolean;
  created_at: string;
  updated_at: string;
}

/**
 * Billing Invoice
 */
export interface BillingInvoice {
  id: string;
  tenant_id: string;
  subscription_id: string;
  invoice_number: string;
  amount: number;
  tax: number;
  total: number;
  status: 'pending' | 'paid' | 'overdue' | 'cancelled';
  billing_period_start: string;
  billing_period_end: string;
  due_date: string;
  paid_at?: string;
  payment_method?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

/**
 * API Response Wrapper
 */
export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
  details?: string;
}

/**
 * Authentication Response
 */
export interface AuthResponse {
  tenant: Partial<Tenant>;
  user: Partial<TenantUser>;
  token: string;
}

/**
 * Product (tenant-specific)
 */
export interface Product {
  id: string;
  category_id?: string;
  sku: string;
  barcode?: string;
  name: string;
  description?: string;
  image_url?: string;
  cost_price: number;
  selling_price: number;
  tax_rate: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

/**
 * Transaction (tenant-specific)
 */
export interface Transaction {
  id: string;
  transaction_number: string;
  customer_id?: string;
  cashier_id?: string;
  subtotal: number;
  tax_amount: number;
  discount_amount: number;
  total_amount: number;
  payment_method: 'cash' | 'card' | 'cheque' | 'online' | 'other';
  payment_status: 'pending' | 'completed' | 'failed' | 'refunded';
  status: 'draft' | 'completed' | 'refunded' | 'cancelled';
  notes?: string;
  created_at: string;
  updated_at: string;
}

/**
 * Customer (tenant-specific)
 */
export interface Customer {
  id: string;
  customer_code: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  postal_code?: string;
  loyalty_points: number;
  total_purchases: number;
  total_spent: number;
  is_active: boolean;
  first_purchase_at?: string;
  last_purchase_at?: string;
  created_at: string;
  updated_at: string;
}
