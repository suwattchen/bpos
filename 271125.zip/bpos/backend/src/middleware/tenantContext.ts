import { Request, Response, NextFunction } from 'express';
import { getTenantDatabaseManager } from '../services/tenantDatabaseManager';
import { Pool } from 'pg';

/**
 * Extended Express Request with tenant context
 */
export interface TenantRequest extends Request {
  tenantId?: string;
  tenantDb?: Pool;
  userId?: string;
  userRole?: string;
}

/**
 * Middleware to extract and validate tenant from JWT token
 * Attaches tenant database pool to request
 */
export async function tenantContextMiddleware(
  req: TenantRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader?.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing authorization token' });
      return;
    }

    const token = authHeader.substring(7);
    
    // Decode JWT to get tenant ID and user info
    const decoded = decodeJWT(token);
    
    if (!decoded || !decoded.tenantId) {
      res.status(401).json({ error: 'Invalid token' });
      return;
    }

    req.tenantId = decoded.tenantId;
    req.userId = decoded.userId;
    req.userRole = decoded.role;

    // Get tenant database pool
    const manager = getTenantDatabaseManager();
    req.tenantDb = await manager.getOrCreateTenantPool(decoded.tenantId);

    // Verify tenant is active
    const tenant = await manager.getTenantDatabaseConfig(decoded.tenantId);
    if (!tenant) {
      res.status(401).json({ error: 'Tenant not found' });
      return;
    }

    next();
  } catch (error) {
    console.error('Tenant context middleware error:', error);
    res.status(401).json({ error: 'Authentication failed' });
  }
}

/**
 * Simple JWT decoder (implement based on your JWT_SECRET)
 * In production, use jsonwebtoken.verify()
 */
function decodeJWT(token: string): any {
  try {
    // This is a simplified version
    // In production, use: jwt.verify(token, JWT_SECRET)
    const parts = token.split('.');
    if (parts.length !== 3) return null;

    const decoded = JSON.parse(Buffer.from(parts[1], 'base64').toString());
    return decoded;
  } catch (error) {
    return null;
  }
}

/**
 * Helper function to query tenant database
 */
export async function queryTenant(
  req: TenantRequest,
  sql: string,
  params?: (string | number | boolean | null)[]
): Promise<any> {
  if (!req.tenantDb) {
    throw new Error('Tenant database connection not available');
  }
  return req.tenantDb.query(sql, params);
}

/**
 * Helper function to execute transaction in tenant database
 */
export async function transactionTenant(
  req: TenantRequest,
  callback: (client: any) => Promise<any>
): Promise<any> {
  if (!req.tenantDb) {
    throw new Error('Tenant database connection not available');
  }

  const client = await req.tenantDb.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}
