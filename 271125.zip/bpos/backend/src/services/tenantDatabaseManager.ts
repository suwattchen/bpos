import { Pool, QueryResult } from 'pg';
import { config } from '../config';
import fs from 'fs';
import path from 'path';

/**
 * Tenant Database Manager
 * Handles dynamic database creation, deletion, and connection pooling per tenant
 * Strategy: Database per Tenant (complete isolation)
 */

interface TenantConnection {
  pool: Pool;
  createdAt: number;
  lastUsed: number;
}

interface TenantDatabaseConfig {
  tenant_id: string;
  name: string;
  user: string;
  password: string;
  host: string;
  port: number;
}

class TenantDatabaseManager {
  private masterPool: Pool;
  private tenantPools: Map<string, TenantConnection> = new Map();
  private maxPoolAge = 1000 * 60 * 60; // 1 hour
  private cleanupInterval = 1000 * 60 * 30; // 30 minutes

  constructor() {
    // Initialize master pool for managing tenants
    this.masterPool = new Pool({
      host: config.database.host,
      port: config.database.port,
      database: 'postgres', // Connect to default postgres DB
      user: config.database.user,
      password: config.database.password,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });

    // Start cleanup interval
    this.startCleanupInterval();
  }

  /**
   * Get or create a database connection pool for a tenant
   */
  async getOrCreateTenantPool(tenantId: string, tenantDatabaseName?: string): Promise<Pool> {
    // Check if pool exists and is still valid
    if (this.tenantPools.has(tenantId)) {
      const connection = this.tenantPools.get(tenantId)!;
      connection.lastUsed = Date.now();
      return connection.pool;
    }

    // Create new pool for tenant
    const dbName = tenantDatabaseName || `tenant_${tenantId.replace(/-/g, '_')}`;
    const pool = new Pool({
      host: config.database.host,
      port: config.database.port,
      database: dbName,
      user: `tenant_${tenantId.replace(/-/g, '_')}`,
      password: await this.generateSecurePassword(),
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });

    // Test connection
    try {
      const client = await pool.connect();
      client.release();
    } catch (error) {
      await pool.end();
      throw new Error(`Failed to connect to tenant database ${dbName}: ${error}`);
    }

    // Store pool
    this.tenantPools.set(tenantId, {
      pool,
      createdAt: Date.now(),
      lastUsed: Date.now(),
    });

    console.log(`✅ Created connection pool for tenant: ${tenantId}`);
    return pool;
  }

  /**
   * Create a new tenant database
   * Called during tenant registration
   */
  async createTenantDatabase(tenantId: string, tenantName: string): Promise<TenantDatabaseConfig> {
    const dbName = `tenant_${tenantId.replace(/-/g, '_')}`;
    const username = `tenant_${tenantId.replace(/-/g, '_')}`;
    const password = await this.generateSecurePassword();

    try {
      const client = await this.masterPool.connect();

      try {
        // Create database
        await client.query(`CREATE DATABASE "${dbName}"`);
        console.log(`✅ Created database: ${dbName}`);

        // Create role/user
        await client.query(`
          CREATE ROLE ${username} WITH LOGIN PASSWORD '${password}' VALID UNTIL 'infinity'
        `);
        console.log(`✅ Created role: ${username}`);

        // Grant privileges
        await client.query(`
          GRANT ALL PRIVILEGES ON DATABASE "${dbName}" TO ${username}
        `);
        console.log(`✅ Granted privileges to ${username}`);

        // Store credentials in master database for tracking
        await client.query(
          `
          INSERT INTO tenant_databases (tenant_id, database_name, username, password, host, port, status)
          VALUES ($1, $2, $3, $4, $5, $6, $7)
          ON CONFLICT (tenant_id) DO UPDATE SET status = 'active'
          `,
          [tenantId, dbName, username, password, config.database.host, config.database.port, 'active']
        );

        return {
          tenant_id: tenantId,
          name: dbName,
          user: username,
          password,
          host: config.database.host,
          port: config.database.port,
        };
      } finally {
        client.release();
      }
    } catch (error) {
      throw new Error(`Failed to create tenant database: ${error}`);
    }
  }

  /**
   * Initialize tenant database with schema
   */
  async initializeTenantDatabase(tenantId: string, tenantName: string): Promise<void> {
    const pool = await this.getOrCreateTenantPool(tenantId);

    try {
      // Read and execute schema SQL
      const schemaPath = path.join(__dirname, '../../database/tenant_schema.sql');
      
      if (!fs.existsSync(schemaPath)) {
        throw new Error(`Tenant schema file not found: ${schemaPath}`);
      }

      const schemaSql = fs.readFileSync(schemaPath, 'utf-8');

      // Execute schema
      await pool.query(schemaSql);
      
      // Insert tenant record
      await pool.query(
        `
        INSERT INTO tenants (id, name, slug, subscription_status)
        VALUES ($1, $2, $3, $4)
        `,
        [tenantId, tenantName, tenantName.toLowerCase().replace(/\s+/g, '-'), 'active']
      );

      console.log(`✅ Initialized database schema for tenant: ${tenantId}`);
    } catch (error) {
      throw new Error(`Failed to initialize tenant database: ${error}`);
    }
  }

  /**
   * Delete a tenant database
   * Called during tenant deletion/suspension
   */
  async deleteTenantDatabase(tenantId: string): Promise<void> {
    const dbName = `tenant_${tenantId.replace(/-/g, '_')}`;
    const username = `tenant_${tenantId.replace(/-/g, '_')}`;

    try {
      // Close pool if exists
      if (this.tenantPools.has(tenantId)) {
        const connection = this.tenantPools.get(tenantId)!;
        await connection.pool.end();
        this.tenantPools.delete(tenantId);
      }

      const client = await this.masterPool.connect();

      try {
        // Terminate existing connections
        await client.query(
          `SELECT pg_terminate_backend(pg_stat_activity.pid)
           FROM pg_stat_activity
           WHERE pg_stat_activity.datname = $1`,
          [dbName]
        );

        // Drop database
        await client.query(`DROP DATABASE IF EXISTS "${dbName}"`);
        console.log(`✅ Dropped database: ${dbName}`);

        // Drop role
        await client.query(`DROP ROLE IF EXISTS ${username}`);
        console.log(`✅ Dropped role: ${username}`);

        // Update tracking table
        await client.query(
          `UPDATE tenant_databases SET status = 'deleted' WHERE tenant_id = $1`,
          [tenantId]
        );
      } finally {
        client.release();
      }
    } catch (error) {
      throw new Error(`Failed to delete tenant database: ${error}`);
    }
  }

  /**
   * Execute query on specific tenant's database
   */
  async queryTenant(
    tenantId: string,
    sql: string,
    params?: (string | number | boolean | null)[]
  ): Promise<QueryResult> {
    const pool = await this.getOrCreateTenantPool(tenantId);
    return pool.query(sql, params);
  }

  /**
   * Get tenant connection details from master database
   */
  async getTenantDatabaseConfig(tenantId: string): Promise<TenantDatabaseConfig | null> {
    try {
      const result = await this.masterPool.query(
        `SELECT tenant_id, database_name as name, username as user, password, host, port
         FROM tenant_databases
         WHERE tenant_id = $1 AND status = 'active'`,
        [tenantId]
      );

      if (result.rows.length === 0) {
        return null;
      }

      return result.rows[0];
    } catch (error) {
      console.error('Failed to get tenant database config:', error);
      return null;
    }
  }

  /**
   * List all active tenants
   */
  async listActiveTenants(): Promise<TenantDatabaseConfig[]> {
    try {
      const result = await this.masterPool.query(
        `SELECT tenant_id, database_name as name, username as user, password, host, port
         FROM tenant_databases
         WHERE status = 'active'`
      );

      return result.rows;
    } catch (error) {
      console.error('Failed to list active tenants:', error);
      return [];
    }
  }

  /**
   * Health check for tenant database
   */
  async healthCheckTenant(tenantId: string): Promise<boolean> {
    try {
      const result = await this.queryTenant(tenantId, 'SELECT 1');
      return result.rows.length > 0;
    } catch (error) {
      console.error(`Health check failed for tenant ${tenantId}:`, error);
      return false;
    }
  }

  /**
   * Generate secure password
   */
  private async generateSecurePassword(): Promise<string> {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 32; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  }

  /**
   * Cleanup old pools
   */
  private startCleanupInterval(): void {
    setInterval(() => {
      const now = Date.now();
      const toDelete: string[] = [];

      this.tenantPools.forEach((connection, tenantId) => {
        // Remove idle pools older than maxPoolAge
        if (now - connection.lastUsed > this.maxPoolAge) {
          toDelete.push(tenantId);
        }
      });

      toDelete.forEach(async (tenantId) => {
        try {
          const connection = this.tenantPools.get(tenantId)!;
          await connection.pool.end();
          this.tenantPools.delete(tenantId);
          console.log(`🧹 Cleaned up idle pool for tenant: ${tenantId}`);
        } catch (error) {
          console.error(`Failed to cleanup pool for tenant ${tenantId}:`, error);
        }
      });
    }, this.cleanupInterval);
  }

  /**
   * Close all connections
   */
  async shutdown(): Promise<void> {
    console.log('Shutting down tenant database manager...');

    // Close all tenant pools
    for (const [tenantId, connection] of this.tenantPools) {
      try {
        await connection.pool.end();
        console.log(`✅ Closed pool for tenant: ${tenantId}`);
      } catch (error) {
        console.error(`Error closing pool for tenant ${tenantId}:`, error);
      }
    }

    // Close master pool
    try {
      await this.masterPool.end();
      console.log('✅ Closed master pool');
    } catch (error) {
      console.error('Error closing master pool:', error);
    }
  }
}

// Singleton instance
let instance: TenantDatabaseManager;

export function getTenantDatabaseManager(): TenantDatabaseManager {
  if (!instance) {
    instance = new TenantDatabaseManager();
  }
  return instance;
}

export { TenantDatabaseManager };
