import { Pool } from 'pg';
import { config } from '../config';
import logger from './logger';

interface AuditLog {
  id?: string;
  user_id: string | null;
  tenant_id: string | null;
  action: string;
  details: object;
  ip_address: string | null;
  timestamp?: Date;
}

/**
 * Master database pool for audit logs
 */
let masterDb: Pool;

function getMasterDb(): Pool {
  if (!masterDb) {
    masterDb = new Pool({
      host: config.database.host,
      port: config.database.port,
      database: 'pos_system', // Master database name
      user: config.database.user,
      password: config.database.password,
      max: 5, // Smaller pool for audit as it's less frequent than tenant ops
    });
  }
  return masterDb;
}

export class AuditService {
  constructor() {
    getMasterDb(); // Initialize the pool on service creation
  }

  public async logActivity(
    userId: string | null,
    tenantId: string | null,
    action: string,
    details: object,
    ipAddress: string | null = null
  ): Promise<void> {
    try {
      const query = `
        INSERT INTO audit_logs (user_id, tenant_id, action, details, ip_address)
        VALUES ($1, $2, $3, $4, $5)
      `;
      const values = [userId, tenantId, action, JSON.stringify(details), ipAddress];
      await masterDb.query(query, values);
      logger.info(`Audit: ${action} by user ${userId || 'N/A'} on tenant ${tenantId || 'N/A'}`);
    } catch (error) {
      logger.error('Failed to write audit log:', error);
    }
  }

  public async logLogin(
    userId: string | null,
    email: string,
    success: boolean,
    ipAddress: string | null = null,
    tenantId: string | null = null
  ): Promise<void> {
    const action = success ? 'USER_LOGIN_SUCCESS' : 'USER_LOGIN_FAILURE';
    const details = { email, success };
    await this.logActivity(userId, tenantId, action, details, ipAddress);
  }

  public async logTenantAction(
    adminId: string,
    tenantId: string,
    action: string,
    details: object,
    ipAddress: string | null = null
  ): Promise<void> {
    const fullAction = `ADMIN_TENANT_${action.toUpperCase()}`;
    await this.logActivity(adminId, tenantId, fullAction, details, ipAddress);
  }

  public async getAuditLogs(
    limit: number = 100,
    offset: number = 0,
    filter: { userId?: string; tenantId?: string; action?: string } = {}
  ): Promise<AuditLog[]> {
    try {
      let query = `SELECT * FROM audit_logs`;
      const conditions: string[] = [];
      const values: (string | number)[] = [];
      let paramIndex = 1;

      if (filter.userId) {
        conditions.push(`user_id = $${paramIndex++}`);
        values.push(filter.userId);
      }
      if (filter.tenantId) {
        conditions.push(`tenant_id = $${paramIndex++}`);
        values.push(filter.tenantId);
      }
      if (filter.action) {
        conditions.push(`action ILIKE $${paramIndex++}`);
        values.push(`%${filter.action}%`);
      }

      if (conditions.length > 0) {
        query += ` WHERE ${conditions.join(' AND ')}`;
      }

      query += ` ORDER BY timestamp DESC LIMIT $${paramIndex++} OFFSET $${paramIndex++}`;
      values.push(limit, offset);

      const result = await masterDb.query(query, values);
      return result.rows;
    } catch (error) {
      logger.error('Failed to fetch audit logs:', error);
      return [];
    }
  }
}

export const auditService = new AuditService();
