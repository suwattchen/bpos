import { Router, Response } from 'express';
import { getTenantDatabaseManager } from '../services/tenantDatabaseManager';
import { config } from '../config';
import { Pool } from 'pg';
import { auditService } from '../services/auditService';
import logger from '../services/logger';

export interface AuthRequest extends Express.Request {
  tenantId?: string;
  userId?: string;
  userRole?: string;
  tenantDb?: Pool;
}

const router = Router();

/**
 * Master database pool for admin operations
 */
let masterDb: Pool;

function getMasterDb(): Pool {
  if (!masterDb) {
    masterDb = new Pool({
      host: config.database.host,
      port: config.database.port,
      database: 'pos_system',
      user: config.database.user,
      password: config.database.password,
      max: 10,
    });
  }
  return masterDb;
}

/**
 * Middleware to check if user is super admin
 */
function isSuperAdmin(req: AuthRequest, res: Response): boolean {
  if (req.userRole !== 'super_admin' && req.userRole !== 'admin') {
    res.status(403).json({ error: 'Insufficient permissions' });
    return false;
  }
  return true;
}

/**
 * List all tenants with their subscription info
 * GET /admin/tenants
 */
router.get('/tenants', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const masterPool = getMasterDb();
    const result = await masterPool.query(`
      SELECT
        td.tenant_id,
        td.database_name,
        td.status,
        td.created_at,
        td.updated_at,
        ts.plan_name,
        ts.status as subscription_status
      FROM tenant_databases td
      LEFT JOIN tenant_subscriptions ts ON td.tenant_id = ts.tenant_id
      ORDER BY td.created_at DESC
    `);

    res.json({
      success: true,
      data: result.rows,
    });
  } catch (error) {
    console.error('Failed to list tenants:', error);
    res.status(500).json({ error: 'Failed to list tenants' });
  }
});

/**
 * Get tenant subscription info
 * GET /admin/tenants/:tenantId/subscription
 */
router.get('/tenants/:tenantId/subscription', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const { tenantId } = req.params;
    const masterPool = getMasterDb();

    const result = await masterPool.query(`
      SELECT
        id,
        tenant_id,
        plan_name,
        status,
        billing_cycle,
        amount,
        max_users,
        max_daily_transactions,
        features,
        started_at,
        renews_at,
        auto_renew,
        created_at,
        updated_at
      FROM tenant_subscriptions
      WHERE tenant_id = $1
    `, [tenantId]);

    if (result.rows.length === 0) {
      res.status(404).json({ error: 'Subscription not found' });
      return;
    }

    res.json({
      success: true,
      data: result.rows[0],
    });
  } catch (error) {
    console.error('Failed to get subscription:', error);
    res.status(500).json({ error: 'Failed to get subscription' });
  }
});

/**
 * Get admin dashboard stats
 * GET /admin/stats
 */
router.get('/stats', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const masterPool = getMasterDb();

    const stats = await Promise.all([
      // Total tenants
      masterPool.query('SELECT COUNT(*) as count FROM tenant_databases'),
      // Active tenants
      masterPool.query("SELECT COUNT(*) as count FROM tenant_databases WHERE status = 'active'"),
      // Suspended tenants
      masterPool.query("SELECT COUNT(*) as count FROM tenant_databases WHERE status = 'suspended'"),
      // Monthly revenue
      masterPool.query(`
        SELECT COALESCE(SUM(amount), 0) as total
        FROM billing_invoices
        WHERE status = 'paid' AND EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM now())
      `),
    ]);

    res.json({
      success: true,
      data: {
        total_tenants: parseInt(stats[0].rows[0].count),
        active_tenants: parseInt(stats[1].rows[0].count),
        suspended_tenants: parseInt(stats[2].rows[0].count),
        monthly_revenue: parseFloat(stats[3].rows[0].total || 0),
        total_users: 0, // TODO: Calculate from all tenant databases
        total_transactions: 0, // TODO: Calculate from all tenant databases
      },
    });
  } catch (error) {
    console.error('Failed to get stats:', error);
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

/**
 * Suspend a tenant
 * POST /admin/tenants/:tenantId/suspend
 */
router.post('/tenants/:tenantId/suspend', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const { tenantId } = req.params;
    const { reason } = req.body;
    const adminId = req.userId!;
    const masterPool = getMasterDb();

    await masterPool.query(`
      UPDATE tenant_databases
      SET status = 'suspended', updated_at = now()
      WHERE tenant_id = $1
    `, [tenantId]);

    await masterPool.query(`
      UPDATE tenant_subscriptions
      SET status = 'suspended'
      WHERE tenant_id = $1
    `, [tenantId]);

    auditService.logTenantAction(adminId, tenantId, 'SUSPEND', { reason: reason || 'No reason provided' }, req.ip);
    logger.info(`Tenant ${tenantId} suspended by admin ${adminId}`);

    res.json({
      success: true,
      message: 'Tenant suspended successfully',
    });
  } catch (error) {
    logger.error(`Failed to suspend tenant ${req.params.tenantId}:`, error);
    res.status(500).json({ error: 'Failed to suspend tenant' });
  }
});

/**
 * Activate a suspended tenant
 * POST /admin/tenants/:tenantId/activate
 */
router.post('/tenants/:tenantId/activate', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const { tenantId } = req.params;
    const adminId = req.userId!;
    const masterPool = getMasterDb();

    await masterPool.query(`
      UPDATE tenant_databases
      SET status = 'active', updated_at = now()
      WHERE tenant_id = $1
    `, [tenantId]);

    await masterPool.query(`
      UPDATE tenant_subscriptions
      SET status = 'active'
      WHERE tenant_id = $1
    `, [tenantId]);

    auditService.logTenantAction(adminId, tenantId, 'ACTIVATE', {}, req.ip);
    logger.info(`Tenant ${tenantId} activated by admin ${adminId}`);

    res.json({
      success: true,
      message: 'Tenant activated successfully',
    });
  } catch (error) {
    logger.error(`Failed to activate tenant ${req.params.tenantId}:`, error);
    res.status(500).json({ error: 'Failed to activate tenant' });
  }
});

/**
 * Delete a tenant completely
 * DELETE /admin/tenants/:tenantId
 */
router.delete('/tenants/:tenantId', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const { tenantId } = req.params;
    const adminId = req.userId!;
    const tenantManager = getTenantDatabaseManager();
    const masterPool = getMasterDb();

    // Delete tenant database
    await tenantManager.deleteTenantDatabase(tenantId);

    // Delete from master database
    await masterPool.query(`
      DELETE FROM tenant_databases WHERE tenant_id = $1
    `, [tenantId]);

    auditService.logTenantAction(adminId, tenantId, 'DELETE', {}, req.ip);
    logger.info(`Tenant ${tenantId} deleted by admin ${adminId}`);

    res.json({
      success: true,
      message: 'Tenant deleted successfully',
    });
  } catch (error) {
    logger.error(`Failed to delete tenant ${req.params.tenantId}:`, error);
    res.status(500).json({ error: 'Failed to delete tenant' });
  }
});

/**
 * Get tenant details
 * GET /admin/tenants/:tenantId
 */
router.get('/tenants/:tenantId', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const { tenantId } = req.params;
    const masterPool = getMasterDb();

    const tenantResult = await masterPool.query(`
      SELECT
        td.tenant_id,
        td.database_name,
        td.status,
        td.created_at,
        td.updated_at,
        ts.plan_name,
        ts.status as subscription_status,
        ts.amount,
        ts.started_at,
        ts.renews_at
      FROM tenant_databases td
      LEFT JOIN tenant_subscriptions ts ON td.tenant_id = ts.tenant_id
      WHERE td.tenant_id = $1
    `, [tenantId]);

    if (tenantResult.rows.length === 0) {
      res.status(404).json({ error: 'Tenant not found' });
      return;
    }

    // Get recent transactions count
    const transactionsResult = await masterPool.query(`
      SELECT COUNT(*) as count
      FROM billing_invoices
      WHERE tenant_id = $1 AND created_at > NOW() - INTERVAL '30 days'
    `, [tenantId]);

    const tenant = tenantResult.rows[0];
    tenant.recent_transactions = parseInt(transactionsResult.rows[0].count);

    res.json({
      success: true,
      data: tenant,
    });
  } catch (error) {
    console.error('Failed to get tenant details:', error);
    res.status(500).json({ error: 'Failed to get tenant details' });
  }
});

/**
 * Update tenant subscription plan
 * PUT /admin/tenants/:tenantId/subscription
 */
router.put('/tenants/:tenantId/subscription', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const { tenantId } = req.params;
    const { plan_name } = req.body;

    if (!['basic', 'professional', 'enterprise'].includes(plan_name)) {
      res.status(400).json({ error: 'Invalid plan name' });
      return;
    }

    const masterPool = getMasterDb();

    await masterPool.query(`
      UPDATE tenant_subscriptions
      SET plan_name = $1, updated_at = now()
      WHERE tenant_id = $2
    `, [plan_name, tenantId]);

    res.json({
      success: true,
      message: 'Subscription updated successfully',
    });
  } catch (error) {
    console.error('Failed to update subscription:', error);
    res.status(500).json({ error: 'Failed to update subscription' });
  }
});

/**
 * Get billing invoices for tenant
 * GET /admin/tenants/:tenantId/invoices
 */
router.get('/tenants/:tenantId/invoices', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const { tenantId } = req.params;
    const masterPool = getMasterDb();

    const result = await masterPool.query(`
      SELECT
        id,
        invoice_number,
        amount,
        tax,
        total,
        status,
        billing_period_start,
        billing_period_end,
        due_date,
        paid_at,
        created_at
      FROM billing_invoices
      WHERE tenant_id = $1
      ORDER BY created_at DESC
      LIMIT 50
    `, [tenantId]);

    res.json({
      success: true,
      data: result.rows,
    });
  } catch (error) {
    console.error('Failed to get invoices:', error);
    res.status(500).json({ error: 'Failed to get invoices' });
  }
});

/**
 * Get audit logs
 * GET /admin/audit-logs
 */
router.get('/audit-logs', async (req: AuthRequest, res: Response) => {
  if (!isSuperAdmin(req, res)) return;

  try {
    const masterPool = getMasterDb();
    const limit = parseInt(req.query.limit as string) || 100;

    const result = await masterPool.query(`
      SELECT
        id,
        user_id,
        action,
        tenant_id,
        details,
        created_at
      FROM master_audit_logs
      ORDER BY created_at DESC
      LIMIT $1
    `, [limit]);

    res.json({
      success: true,
      data: result.rows,
    });
  } catch (error) {
    console.error('Failed to get audit logs:', error);
    res.status(500).json({ error: 'Failed to get audit logs' });
  }
});

export default router;
