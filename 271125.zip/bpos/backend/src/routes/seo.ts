import { Router, Response, Request } from 'express';

const router = Router();

/**
 * Public SEO endpoints - no authentication required
 */

// Health check
router.get('/health', (req: Request, res: Response) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
  });
});

// Sitemap endpoint for dynamic generation
router.get('/sitemap.xml', (req: Request, res: Response) => {
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:mobile="http://www.google.com/schemas/sitemap-mobile/1.0">
  <url>
    <loc>https://sunmart-pos.com/</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
    <mobile:mobile/>
  </url>
  <url>
    <loc>https://sunmart-pos.com/features</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
    <mobile:mobile/>
  </url>
  <url>
    <loc>https://sunmart-pos.com/pricing</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
    <mobile:mobile/>
  </url>
  <url>
    <loc>https://sunmart-pos.com/about</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
    <mobile:mobile/>
  </url>
</urlset>`;

  res.header('Content-Type', 'application/xml');
  res.send(sitemap);
});

// robots.txt endpoint
router.get('/robots.txt', (req: Request, res: Response) => {
  const robots = `# Sunmart POS - robots.txt
User-agent: *
Allow: /
Allow: /about
Allow: /features
Allow: /pricing
Allow: /contact
Allow: /support

Disallow: /admin
Disallow: /dashboard
Disallow: /app
Disallow: /api
Disallow: /auth
Disallow: /*.json$
Disallow: /*?*

Sitemap: /sitemap.xml
Crawl-delay: 1`;

  res.header('Content-Type', 'text/plain');
  res.send(robots);
});

// Platform stats for SEO (optional)
router.get('/stats', async (req: Request, res: Response) => {
  res.json({
    platform: 'Sunmart POS',
    status: 'operational',
    version: '1.0.0',
    description: 'Free multi-tenant point of sale system for Thai businesses',
    features: [
      'Multi-tenant architecture',
      'Real-time inventory management',
      'Sales analytics',
      'Admin dashboard',
      'User role management',
      'Cloud-based',
      'Forever free'
    ],
    location: 'Udon Thani, Thailand',
    contact: {
      email: 'suwattchen@gmail.com',
      phone: '+66 81 240 1237',
      github: 'https://github.com/suwattchen/bpos'
    },
    timestamp: new Date().toISOString(),
  });
});

export default router;
