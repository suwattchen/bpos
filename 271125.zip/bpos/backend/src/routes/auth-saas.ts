import { Router, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { getTenantDatabaseManager } from '../services/tenantDatabaseManager';
import { config } from '../config';
import { v4 as uuidv4 } from 'uuid';
import { Pool } from 'pg';
import { auditService } from '../services/auditService';
import logger from '../services/logger';

export interface AuthRequest extends Express.Request {
  tenantId?: string;
}

const router = Router();

/**
 * Master database pool for tenant registration and login
 */
let masterDb: Pool;

function getMasterDb(): Pool {
  if (!masterDb) {
    masterDb = new Pool({
      host: config.database.host,
      port: config.database.port,
      database: 'pos_system', // Master database name
      user: config.database.user,
      password: config.database.password,
      max: 10,
    });
  }
  return masterDb;
}

/**
 * Register a new tenant
 * POST /auth/register-tenant
 * Body: {
 *   email: string,
 *   password: string,
 *   tenant_name: string,
 *   owner_name?: string,
 *   phone?: string
 * }
 */
router.post('/register-tenant', async (req: AuthRequest, res: Response) => {
  const { email, password, tenant_name, owner_name, phone } = req.body;

  try {
    // Validate input
    if (!email || !password || !tenant_name) {
      res.status(400).json({ error: 'Missing required fields: email, password, tenant_name' });
      return;
    }

    if (password.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters' });
      return;
    }

    const masterPool = getMasterDb();
    const tenantManager = getTenantDatabaseManager();
    const tenantId = uuidv4();
    const userId = uuidv4();
    const hashedPassword = await bcrypt.hash(password, 10);

    // Start transaction in master DB
    const client = await masterPool.connect();

    try {
      await client.query('BEGIN');

      // 1. Check if email already exists
      const existingEmail = await client.query(
        `SELECT id FROM tenant_users WHERE email = $1`,
        [email]
      );

      if (existingEmail.rows.length > 0) {
        res.status(400).json({ error: 'Email already registered' });
        await client.query('ROLLBACK');
        return;
      }

      // 2. Create tenant database
      const dbConfig = await tenantManager.createTenantDatabase(tenantId, tenant_name);
      console.log(`✅ Created tenant database for: ${tenant_name}`);

      // 3. Initialize tenant database schema
      await tenantManager.initializeTenantDatabase(tenantId, tenant_name);
      console.log(`✅ Initialized schema for tenant: ${tenantId}`);

      // 4. Get tenant pool and create owner user
      const tenantPool = await tenantManager.getOrCreateTenantPool(tenantId);

      const ownerResult = await tenantPool.query(
        `
        INSERT INTO tenant_users (id, email, encrypted_password, full_name, phone, role, is_active)
        VALUES ($1, $2, $3, $4, $5, $6, true)
        RETURNING id, email, role
        `,
        [userId, email, hashedPassword, owner_name || 'Owner', phone || null, 'owner']
      );

      // 5. Store tenant email mapping in master DB for easy lookup
      await client.query(
        `
        INSERT INTO tenant_emails (tenant_id, email)
        VALUES ($1, $2)
        `,
        [tenantId, email]
      );

      await client.query('COMMIT');

      // 6. Generate JWT token
      const token = jwt.sign(
        {
          tenantId,
          userId,
          email,
          role: 'owner',
        },
        config.jwt.secret,
        { expiresIn: config.jwt.expiresIn }
      );

      res.status(201).json({
        success: true,
        message: 'Tenant registered successfully',
        data: {
          tenant: {
            id: tenantId,
            name: tenant_name,
          },
          user: {
            id: userId,
            email,
            role: 'owner',
          },
          token,
        },
      });
    } catch (error) {
      await client.query('ROLLBACK');
      logger.error(`Tenant registration failed for ${email}:`, error);
      auditService.logLogin(null, email, false, req.ip, null); // Log failed registration as login attempt
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    logger.error('Register tenant error:', error);
    res.status(500).json({
      error: 'Failed to register tenant',
      details: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

/**
 * Login to tenant
 * POST /auth/login
 * Body: {
 *   email: string,
 *   password: string
 * }
 */
router.post('/login', async (req: AuthRequest, res: Response) => {
  const { email, password } = req.body;

  try {
    if (!email || !password) {
      logger.warn(`Login attempt with missing credentials from IP: ${req.ip}`);
      auditService.logLogin(null, email || 'N/A', false, req.ip, null);
      res.status(400).json({ error: 'Missing email or password' });
      return;
    }

    const masterPool = getMasterDb();
    const tenantManager = getTenantDatabaseManager();

    // 1. Find tenant by email
    const tenantResult = await masterPool.query(
      `SELECT tenant_id FROM tenant_emails WHERE email = $1`,
      [email]
    );

    if (tenantResult.rows.length === 0) {
      logger.warn(`Login attempt for non-existent email: ${email} from IP: ${req.ip}`);
      auditService.logLogin(null, email, false, req.ip, null);
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    const tenantId = tenantResult.rows[0].tenant_id;

    // 2. Get tenant database connection
    const tenantPool = await tenantManager.getOrCreateTenantPool(tenantId);

    // 3. Find user in tenant database
    const userResult = await tenantPool.query(
      `
      SELECT id, email, encrypted_password, full_name, role, is_active
      FROM tenant_users
      WHERE email = $1 AND is_active = true
      `,
      [email]
    );

    if (userResult.rows.length === 0) {
      logger.error(`User email ${email} found in master but not tenant DB ${tenantId}. Data inconsistency!`);
      auditService.logLogin(null, email, false, req.ip, tenantId); // Log as failure
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    const user = userResult.rows[0];

    // 4. Verify password
    const passwordMatch = await bcrypt.compare(password, user.encrypted_password);

    if (!passwordMatch) {
      logger.warn(`Failed login for ${email} due to invalid password from IP: ${req.ip}`);
      auditService.logLogin(user.id, email, false, req.ip, tenantId);
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    // 5. Check if user is active
    if (!user.is_active) {
      logger.warn(`Login attempt for inactive user ${email} (ID: ${user.id}, Tenant: ${tenantId}) from IP: ${req.ip}`);
      auditService.logLogin(user.id, email, false, req.ip, tenantId);
      res.status(403).json({ error: 'Account is inactive. Please contact your administrator.' });
      return;
    }

    // 6. Update last login
    await tenantPool.query(
      `UPDATE tenant_users SET last_login = now() WHERE id = $1`,
      [user.id]
    );

    // 7. Generate JWT token
    const token = jwt.sign(
      {
        tenantId,
        userId: user.id,
        email: user.email,
        role: user.role,
      },
      config.jwt.secret,
      { expiresIn: config.jwt.expiresIn }
    );
    
    logger.info(`User ${email} (ID: ${user.id}, Tenant: ${tenantId}) logged in successfully from IP: ${req.ip}`);
    auditService.logLogin(user.id, email, true, req.ip, tenantId);

    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: {
          id: user.id,
          email: user.email,
          fullName: user.full_name,
          role: user.role,
        },
        tenantId,
        token,
      },
    });
  } catch (error) {
    logger.error(`Login error for ${email}:`, error);
    auditService.logLogin(null, email || 'N/A', false, req.ip, null); // Catch-all for other errors
    res.status(500).json({
      error: 'Login failed',
      details: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

/**
 * Verify token
 * GET /auth/verify
 */
router.get('/verify', async (req: AuthRequest, res: Response) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader?.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing token' });
      return;
    }

    const token = authHeader.substring(7);

    try {
      const decoded = jwt.verify(token, config.jwt.secret) as any;
      
      res.json({
        success: true,
        data: {
          tenantId: decoded.tenantId,
          userId: decoded.userId,
          email: decoded.email,
          role: decoded.role,
        },
      });
    } catch (error) {
      res.status(401).json({ error: 'Invalid or expired token' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Token verification failed' });
  }
});

/**
 * Refresh token
 * POST /auth/refresh
 */
router.post('/refresh', async (req: AuthRequest, res: Response) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader?.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing token' });
      return;
    }

    const token = authHeader.substring(7);

    const decoded = jwt.verify(token, config.jwt.secret, { ignoreExpiration: true }) as any;

    // Generate new token
    const newToken = jwt.sign(
      {
        tenantId: decoded.tenantId,
        userId: decoded.userId,
        email: decoded.email,
        role: decoded.role,
      },
      config.jwt.secret,
      { expiresIn: config.jwt.expiresIn }
    );

    res.json({
      success: true,
      data: { token: newToken },
    });
  } catch (error) {
    res.status(401).json({ error: 'Token refresh failed' });
  }
});

export default router;
