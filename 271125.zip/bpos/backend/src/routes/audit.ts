import { Router, Response } from 'express';
import { AuthRequest, authenticate } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';
import { auditService } from '../services/auditService';
import logger from '../services/logger';

const router = Router();

// Middleware to check if user is admin or super_admin
const authorizeAdmin = (req: AuthRequest, res: Response, next: Function) => {
  if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'super_admin')) {
    logger.warn(`Unauthorized access to audit logs: User ${req.user?.id || 'N/A'} with role ${req.user?.role || 'N/A'}`);
    throw new AppError('Access denied: Admins only', 403);
  }
  next();
};

/**
 * Get audit logs (Admin only)
 * GET /admin/audit-logs
 * Query: {
 *   limit?: number,
 *   offset?: number,
 *   userId?: string,
 *   tenantId?: string,
 *   action?: string
 * }
 */
router.get('/audit-logs', authenticate, authorizeAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 100;
    const offset = parseInt(req.query.offset as string) || 0;
    const userId = req.query.userId as string || undefined;
    const tenantId = req.query.tenantId as string || undefined;
    const action = req.query.action as string || undefined;

    const logs = await auditService.getAuditLogs(limit, offset, { userId, tenantId, action });
    res.json(logs);
  } catch (error) {
    logger.error('Failed to fetch audit logs:', error);
    throw new AppError('Failed to retrieve audit logs', 500);
  }
});

export default router;
