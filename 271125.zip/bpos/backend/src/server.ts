import express, { Application } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import { config } from './config';
import { errorHandler } from './middleware/errorHandler';
import { notFound } from './middleware/notFound';
import logger from './services/logger';

// Initialize event handlers BEFORE routes
import { initInventoryHandlers } from './modules/inventory';

// Routes
import authSaasRoutes from './routes/auth-saas';
import adminRoutes from './routes/admin';
import productsRoutes from './routes/products';
import inventoryRoutes from './routes/inventory';
import transactionsRoutes from './routes/transactions';
import categoriesRoutes from './routes/categories';
import uploadRoutes from './routes/upload';
import healthRoutes from './routes/health';
import seoRoutes from './routes/seo';
import auditRoutes from './routes/audit';

const app: Application = express();

// Initialize event-driven architecture
if (config.nodeEnv !== 'test') {
  console.log('🎯 Initializing event-driven architecture...');
  initInventoryHandlers();
  console.log('✅ Event handlers initialized');
}

// Security middleware
app.use(helmet());
app.use(cors({
  origin: config.corsOrigin.split(','),
  credentials: true,
}));

// Request parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Compression
app.use(compression());

// Logging
if (config.nodeEnv !== 'test') {
  app.use(morgan('combined', { stream: { write: (message) => logger.info(message.trim()) } }));
}

// Routes
app.use('/health', healthRoutes);
app.use('/seo', seoRoutes);
app.use('/auth', authSaasRoutes);
app.use('/admin', adminRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/transactions', transactionsRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/admin/audit', auditRoutes);

// Error handling
app.use(notFound);
app.use(errorHandler);

// Start server
const PORT = config.port || 3001;

if (config.nodeEnv !== 'test') {
  app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📝 Environment: ${config.nodeEnv}`);
    console.log(`🔗 Database: ${config.database.host}:${config.database.port}`);
  });
}

export default app;
