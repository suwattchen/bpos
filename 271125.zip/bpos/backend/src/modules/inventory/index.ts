export { inventoryService } from './service';
export { initInventoryHandlers } from './handlers';
export type { Product } from './repository';
