# 🏗️ Database-Per-Tenant Strategy Guide

**Last Updated:** November 26, 2025  
**Status:** Implementation Complete ✅

---

## 📋 Table of Contents

1. [Architecture Overview](#-architecture-overview)
2. [How It Works](#-how-it-works)
3. [Database Structure](#-database-structure)
4. [Authentication Flow](#-authentication-flow)
5. [API Endpoints](#-api-endpoints)
6. [Implementation Files](#-implementation-files)
7. [Deployment & Operations](#-deployment--operations)
8. [Troubleshooting](#-troubleshooting)

---

## 🏗️ Architecture Overview

### Multi-Tenant SaaS Database Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                      FRONTEND (React)                        │
│         /auth/register-tenant, /auth/login                  │
└────────────────────────────┬─────────────────────────────────┘
                             │
                    ┌────────▼────────┐
                    │   BACKEND API   │
                    │   (Node.js)     │
                    └────────┬────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
   ┌─────────┐         ┌──────────┐        ┌──────────┐
   │ MASTER  │         │ TENANT 1 │        │ TENANT 2 │
   │   DB    │         │   DB     │        │   DB     │
   │         │         │          │        │          │
   │ • Tenant│         │ • User 1 │        │ • User 3 │
   │   List  │◄────────│ • Data 1 │        │ • Data 3 │
   │ • Users │         │          │        │          │
   │ • Billing│        │ isolated │        │ isolated │
   │          │        │ Schema   │        │ Schema   │
   └─────────┘        └──────────┘        └──────────┘
                         user1@...          user3@...
```

### Key Benefits

✅ **Complete Data Isolation** - Each tenant has separate database  
✅ **Easy Backup/Restore** - Backup individual tenant databases  
✅ **Simple Scaling** - Add new databases as needed  
✅ **Security** - No risk of data leakage between tenants  
✅ **Performance** - No complex WHERE clauses, full index benefit  
✅ **Compliance** - GDPR compliance easier (delete entire DB)

---

## 🔄 How It Works

### 1. Tenant Registration Flow

```
┌─────────────────────────────────────────────────────────┐
│ User enters: email, password, tenant_name               │
└──────────────────────┬──────────────────────────────────┘
                       ▼
┌─────────────────────────────────────────────────────────┐
│ POST /auth/register-tenant (no auth needed)              │
└──────────────────────┬──────────────────────────────────┘
                       ▼
┌─────────────────────────────────────────────────────────┐
│ Backend Actions:                                        │
│ 1. Generate tenant_id (UUID)                            │
│ 2. Create tenant database (tenant_<id>)                 │
│ 3. Create tenant user (tenant_<id>)                     │
│ 4. Initialize schema (products, inventory, etc)         │
│ 5. Create owner user in tenant database                 │
│ 6. Generate JWT token with tenant_id + user_id          │
└──────────────────────┬──────────────────────────────────┘
                       ▼
┌─────────────────────────────────────────────────────────┐
│ Response: { token, tenant, user }                       │
│ Token = jwt(tenantId, userId, email, role)              │
└─────────────────────────────────────────────────────────┘
```

### 2. Login Flow

```
POST /auth/login (no auth needed)
├─ Input: email + password
├─ Find tenant_id using email → master DB
├─ Get tenant database connection
├─ Verify password in tenant database
├─ Generate JWT token
└─ Return: token + user + tenant

# Every subsequent request includes token in Authorization header
```

### 3. Authenticated Request Flow

```
POST /api/products (with Bearer token)
├─ TenantContext Middleware
│  ├─ Extract tenant_id from JWT
│  ├─ Get or create database pool for tenant
│  └─ Attach pool to request (req.tenantDb)
├─ Route Handler
│  ├─ Query only tenant's database
│  ├─ All queries use req.tenantDb pool
│  └─ No tenant_id WHERE clause needed!
└─ Response (isolated data only)
```

---

## 📊 Database Structure

### Master Database (pos_system)

```sql
-- Stores metadata about all tenants
CREATE TABLE tenant_databases (
  tenant_id uuid PRIMARY KEY,
  database_name text UNIQUE,    -- e.g., "tenant_abc123"
  username text UNIQUE,          -- e.g., "tenant_abc123"
  password text,                 -- DB password for this tenant
  host text,                     -- 'localhost' or IP
  port integer,                  -- 5432
  status text,                   -- 'active', 'suspended', 'deleted'
  created_at timestamptz
);

-- Track subscription and billing
CREATE TABLE tenant_subscriptions (
  id uuid PRIMARY KEY,
  tenant_id uuid UNIQUE REFERENCES tenant_databases,
  plan_name text,     -- 'basic', 'professional', 'enterprise'
  status text,        -- 'trial', 'active', 'suspended'
  amount decimal,
  started_at timestamptz,
  renews_at timestamptz
);

-- Email index for fast lookup during login
CREATE TABLE tenant_emails (
  tenant_id uuid UNIQUE REFERENCES tenant_databases,
  email text PRIMARY KEY
);
```

### Tenant Database (tenant_<id>)

```sql
-- Each tenant gets this exact schema
CREATE TABLE tenant_users (
  id uuid PRIMARY KEY,
  email text UNIQUE NOT NULL,
  encrypted_password text,
  role text,          -- 'owner', 'manager', 'cashier'
  is_active boolean
);

CREATE TABLE products (
  id uuid PRIMARY KEY,
  sku text UNIQUE NOT NULL,
  name text NOT NULL,
  selling_price decimal,
  -- No tenant_id needed! Already isolated by DB
);

CREATE TABLE transactions (
  id uuid PRIMARY KEY,
  transaction_number text UNIQUE,
  customer_id uuid,
  total_amount decimal,
  -- All queries automatically isolated
);

-- ... and all other tables (inventory, customers, etc)
```

### Key Difference

```typescript
// ❌ OLD WAY (Schema-per-tenant) - RLS required
SELECT * FROM products WHERE tenant_id = $1;

// ✅ NEW WAY (Database-per-tenant) - NO WHERE needed!
SELECT * FROM products;  // Always safe, other tenant can't access
```

---

## 🔐 Authentication Flow

### Step 1: Registration

```bash
curl -X POST http://localhost:3001/auth/register-tenant \
  -H "Content-Type: application/json" \
  -d '{
    "email": "owner@myshop.com",
    "password": "secure_password_123",
    "tenant_name": "My Coffee Shop",
    "owner_name": "John Doe",
    "phone": "+66812345678"
  }'

# Response:
{
  "success": true,
  "data": {
    "tenant": {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "My Coffee Shop"
    },
    "user": {
      "id": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
      "email": "owner@myshop.com",
      "role": "owner"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Step 2: Subsequent Requests

```bash
# All authenticated requests include token
curl -X GET http://localhost:3001/api/products \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

# Backend extracts tenant_id from token
# Automatically queries that tenant's database
```

---

## 📡 API Endpoints

### Authentication (Public - No Token Required)

```
POST /auth/register-tenant
  ├─ Creates new tenant database
  ├─ Creates owner user
  └─ Returns: JWT token

POST /auth/login
  ├─ Finds tenant by email
  ├─ Verifies password
  └─ Returns: JWT token

GET /auth/verify
  ├─ Requires: Bearer token
  └─ Returns: Token info (tenant_id, user_id, etc)

POST /auth/refresh
  ├─ Requires: Bearer token (expired OK)
  └─ Returns: New token
```

### Products (Protected - Token Required)

```
GET /api/products
  ├─ Returns only this tenant's products
  └─ Middleware adds tenantDb to request

POST /api/products
  ├─ Creates product in this tenant's database
  └─ Automatic tenant isolation

PUT /api/products/:id
  ├─ Updates product (tenant's only)
  └─ No need to check tenant_id

DELETE /api/products/:id
  ├─ Deletes product (tenant's only)
  └─ Safe - can't access other tenant's data
```

### All other routes

```
/api/inventory
/api/customers
/api/transactions
/api/categories
/api/sales/reports
```

All automatically isolated by tenant!

---

## 📁 Implementation Files

### New Files Created

```
backend/
├── src/
│   ├── services/
│   │   └── tenantDatabaseManager.ts  ← Main service (creates/manages DBs)
│   │
│   ├── middleware/
│   │   └── tenantContext.ts         ← Attaches tenantDb to request
│   │
│   └── routes/
│       └── auth-saas.ts             ← Registration + login endpoints

database/
├── tenant_schema.sql                 ← Schema for each tenant DB
│   (Products, Inventory, Transactions, etc - 12 tables + views)
│
└── init/
    └── 01-master-schema.sql         ← Master DB schema
        (Tenant registry, subscriptions, billing, etc)
```

### Modified Files

```
docker-compose.yml
├─ Updated postgres: max_connections=200
├─ Mounts master schema initialization
└─ Added TENANT_DB_* environment variables

.env.example
├─ Added TENANT_DB_HOST, TENANT_DB_PORT
├─ Added MAX_TENANT_POOL_SIZE
└─ Added POOL_CLEANUP_INTERVAL_MS

backend/package.json (no changes needed, all deps exist)
```

---

## 🚀 Deployment & Operations

### 1. Initial Setup

```bash
# 1. Copy environment template
cp .env.example .env

# 2. Update .env with your values
# IMPORTANT: Change JWT_SECRET and DB passwords!

# 3. Start services
docker-compose up -d --build

# 4. Check master database initialization
docker-compose logs postgres | grep "01-master-schema"

# 5. Verify backend health
curl http://localhost:3001/health
```

### 2. Database Connection Pooling

The `TenantDatabaseManager` handles:

✅ **Lazy Loading** - Only creates DB connection when needed  
✅ **Connection Pooling** - Reuses connections (max 20 per tenant)  
✅ **Automatic Cleanup** - Removes idle pools after 1 hour  
✅ **Health Checks** - Monitors tenant DB connections  
✅ **Error Handling** - Gracefully handles DB failures

```typescript
// Backend automatically manages this:
const manager = getTenantDatabaseManager();

// First request: Creates pool
const pool = await manager.getOrCreateTenantPool(tenantId);

// Subsequent requests: Reuses pool
const pool2 = await manager.getOrCreateTenantPool(tenantId);
// Same pool instance, very fast

// Idle cleanup: After 1 hour of no use
// Pool automatically closed and recreated on next request
```

### 3. Monitoring & Maintenance

```bash
# Check active tenant connections
SELECT * FROM information_schema.schemata WHERE schema_name LIKE 'tenant_%';

# Monitor connection count
SELECT count(*) FROM pg_stat_activity;

# View tenant database sizes
SELECT
  datname,
  pg_size_pretty(pg_database.databasesize(oid)) as size
FROM pg_database
WHERE datname LIKE 'tenant_%'
ORDER BY pg_database.databasesize(oid) DESC;
```

### 4. Backup Strategy

```bash
# Backup specific tenant
pg_dump -h localhost -U pos_admin tenant_abc123 > tenant_abc123_backup.sql

# Restore specific tenant
psql -h localhost -U pos_admin tenant_abc123 < tenant_abc123_backup.sql

# Backup master database
pg_dump -h localhost -U pos_admin pos_system > master_backup.sql

# Or use this script (coming soon):
# ./scripts/backup-tenant.sh <tenant_id>
```

### 5. Suspension & Deletion

```typescript
// Suspend a tenant (subscription expired, etc)
await manager.suspendTenant(tenantId);
// Tenant database still exists, but login denied

// Reactivate a tenant
await manager.activateTenant(tenantId);

// Delete a tenant completely (GDPR)
await manager.deleteTenantDatabase(tenantId);
// Entire database dropped
// Compliant with GDPR "right to be forgotten"
```

---

## 🔧 Troubleshooting

### Issue 1: "Database connection pool exhausted"

**Symptom:** `Error: timeout acquiring a client from the pool`

**Solution:**
```
1. Increase MAX_TENANT_POOL_SIZE in docker-compose.yml
2. Check for abandoned connections:
   SELECT * FROM pg_stat_activity WHERE state != 'idle';
3. Restart backend service:
   docker-compose restart backend
```

### Issue 2: "Tenant database not found"

**Symptom:** `Failed to connect to tenant database tenant_abc123`

**Solution:**
```
1. Check master database for tenant entry:
   SELECT * FROM tenant_databases WHERE tenant_id = '<id>';
2. Verify database exists:
   \l | grep tenant_
3. Recreate if missing:
   SELECT create_new_tenant(...) from master DB
```

### Issue 3: "Invalid token / tenant mismatch"

**Symptom:** Request fails with 401 Unauthorized

**Solution:**
```
1. Verify JWT secret matches (.env JWT_SECRET)
2. Check token expiration: GET /auth/verify
3. Refresh token: POST /auth/refresh
4. Re-login if needed: POST /auth/login
```

### Issue 4: "Too many connections"

**Symptom:** `FATAL: too many connections for role`

**Solution:**
```
1. Lower pool size or cleanup pools
2. Add connection pooling service (PgBouncer)
3. Increase PostgreSQL max_connections
4. Example docker-compose change:
   POSTGRES_INITDB_ARGS: "-c max_connections=500"
```

---

## 📈 Next Steps

### Phase 2: Admin Features (Optional)

- [ ] Super admin dashboard to manage all tenants
- [ ] Tenant suspension/activation UI
- [ ] Billing dashboard
- [ ] Usage analytics per tenant
- [ ] Custom domain support (tenant.mypos.com)

### Phase 3: Advanced Features

- [ ] Automated backups per tenant
- [ ] Database migration tools
- [ ] Tenant data export
- [ ] White-label branding
- [ ] API quota management

### Phase 4: Scaling

- [ ] Database replication
- [ ] Read replicas per tenant
- [ ] Horizontal scaling (multiple servers)
- [ ] Geographic distribution
- [ ] CDN for static assets

---

## 📚 References

### Files to Review

1. `backend/src/services/tenantDatabaseManager.ts` - Main implementation
2. `backend/src/middleware/tenantContext.ts` - Request middleware
3. `backend/src/routes/auth-saas.ts` - Auth endpoints
4. `database/tenant_schema.sql` - Tenant database schema
5. `database/init/01-master-schema.sql` - Master database schema

### Related Documentation

- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [Multi-Tenancy Best Practices](https://www.pg-and-spring-boot.online/)
- [JWT Authentication](https://jwt.io/)
- [Node.js pg Pool](https://node-postgres.com/api/pool)

---

**Created:** November 26, 2025  
**Last Modified:** November 26, 2025  
**Status:** ✅ Complete and Ready for Testing
