import { ArrowRight, Shield, Zap, Users, BarChart3, Lock, QrCode, Github, MessageCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useEffect, useState } from 'react';

export function LandingPage() {
  const { isAuthenticated } = useAuth();
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showRegister, setShowRegister] = useState(false);
  const [tenantName, setTenantName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // Set meta tags for SEO
    document.title = 'Sunmart POS - Free Multi-Tenant Point of Sale System | Thailand';
    
    const metaTags = [
      { name: 'description', content: 'Free, open-source multi-tenant POS system for small businesses in Thailand. No setup cost, forever free cloud POS solution. Sunmart Online Thailand.' },
      { name: 'keywords', content: 'POS system, point of sale, free POS, Thai POS, multi-tenant, cloud POS, Sunmart' },
      { name: 'og:title', content: 'Sunmart POS - Free Multi-Tenant Point of Sale' },
      { name: 'og:description', content: 'Forever free cloud-based POS system for Thai businesses. Manage multiple stores with one dashboard.' },
      { name: 'og:type', content: 'website' },
      { property: 'og:url', content: window.location.href },
    ];

    metaTags.forEach(tag => {
      const existing = document.querySelector(`meta[name="${tag.name}"], meta[property="${tag.property || tag.name}"]`);
      if (existing) existing.remove();
      
      const meta = document.createElement('meta');
      if (tag.property) meta.setAttribute('property', tag.property);
      if (tag.name) meta.setAttribute('name', tag.name);
      meta.content = tag.content;
      document.head.appendChild(meta);
    });

    return () => {
      metaTags.forEach(tag => {
        const meta = document.querySelector(`meta[name="${tag.name}"], meta[property="${tag.property || tag.name}"]`);
        if (meta) meta.remove();
      });
    };
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const response = await fetch('/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.token);
        localStorage.setItem('tenantId', data.tenantId);
        window.location.href = '/dashboard';
      } else {
        setError('Invalid email or password');
      }
    } catch (err) {
      setError('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const response = await fetch('/auth/register-tenant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, tenant_name: tenantName }),
      });
      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.token);
        localStorage.setItem('tenantId', data.tenantId);
        window.location.href = '/dashboard';
      } else {
        const data = await response.json();
        setError(data.error || 'Registration failed');
      }
    } catch (err) {
      setError('Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="bg-slate-900/80 backdrop-blur-md border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">S</span>
            </div>
            <span className="text-xl font-bold text-white">Sunmart POS</span>
          </div>
          <button
            onClick={() => {
              setShowLoginForm(true);
              setShowRegister(false);
              setError('');
            }}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
          >
            Login
          </button>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              Free Point of Sale System <span className="text-blue-400">Forever</span>
            </h1>
            <p className="text-xl text-slate-300 mb-8">
              Sunmart POS - ระบบจุดขายแบบ Multi-Tenant สำหรับธุรกิจทั้งหมด ไม่มีค่าลงทะเบียน ไม่มีค่าบำรุงรักษา
            </p>
            <div className="flex gap-4 mb-8">
              <button
                onClick={() => {
                  setShowLoginForm(true);
                  setShowRegister(true);
                  setError('');
                }}
                className="px-8 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-lg font-semibold flex items-center gap-2 transition"
              >
                Get Started Free <ArrowRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => window.open('https://github.com', '_blank')}
                className="px-8 py-3 border border-slate-400 hover:border-slate-300 text-slate-300 rounded-lg font-semibold flex items-center gap-2 transition"
              >
                <Github className="w-5 h-5" /> View Source
              </button>
            </div>

            {/* Business Info */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 mt-8">
              <h3 className="text-lg font-semibold text-white mb-3">📍 Sunmart Online Thailand</h3>
              <div className="space-y-2 text-slate-300">
                <p>📮 199 Mung, Udon Thani, Thailand 41000</p>
                <p>📧 Email: <a href="mailto:suwattchen@gmail.com" className="text-blue-400 hover:text-blue-300">suwattchen@gmail.com</a></p>
                <p>📱 Phone: <a href="tel:+66812401237" className="text-blue-400 hover:text-blue-300">+66 81 240 1237</a></p>
              </div>
            </div>
          </div>

          {/* Login/Register Form */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-8 backdrop-blur-sm">
            {showLoginForm ? (
              <div>
                <div className="flex gap-2 mb-6">
                  <button
                    onClick={() => setShowRegister(false)}
                    className={`flex-1 py-2 rounded-lg font-semibold transition ${
                      !showRegister
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    Login
                  </button>
                  <button
                    onClick={() => setShowRegister(true)}
                    className={`flex-1 py-2 rounded-lg font-semibold transition ${
                      showRegister
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    Register
                  </button>
                </div>

                <form onSubmit={showRegister ? handleRegister : handleLogin} className="space-y-4">
                  {showRegister && (
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Tenant Name</label>
                      <input
                        type="text"
                        value={tenantName}
                        onChange={(e) => setTenantName(e.target.value)}
                        placeholder="Your Store Name"
                        className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
                        required
                      />
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Email</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Password</label>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
                      required
                    />
                  </div>
                  {error && <p className="text-red-400 text-sm">{error}</p>}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white rounded-lg font-semibold transition"
                  >
                    {loading ? 'Loading...' : showRegister ? 'Create Account' : 'Sign In'}
                  </button>
                </form>

                <p className="text-center text-sm text-slate-400 mt-4">
                  Secure login with encrypted credentials
                </p>
              </div>
            ) : (
              <div className="space-y-4 text-center py-8">
                <h3 className="text-2xl font-bold text-white mb-4">Ready to Get Started?</h3>
                <p className="text-slate-300 mb-6">Click the button above to login or create your free store</p>
                <button
                  onClick={() => setShowLoginForm(true)}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition"
                >
                  Login / Register
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Features Section */}
        <div className="grid md:grid-cols-3 gap-6 mb-20">
          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-500 transition">
            <Shield className="w-12 h-12 text-blue-400 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Secure & Private</h3>
            <p className="text-slate-400">Database-per-tenant architecture ensures your data is completely isolated and secure</p>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-500 transition">
            <Zap className="w-12 h-12 text-yellow-400 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Lightning Fast</h3>
            <p className="text-slate-400">PostgreSQL 17 with optimized queries for instant inventory updates and sales tracking</p>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-500 transition">
            <Users className="w-12 h-12 text-green-400 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Multi-Store</h3>
            <p className="text-slate-400">Manage multiple branches from one dashboard. Real-time inventory sync across all stores</p>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-500 transition">
            <BarChart3 className="w-12 h-12 text-purple-400 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Real-time Analytics</h3>
            <p className="text-slate-400">Live sales reports, inventory levels, and customer insights at your fingertips</p>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-500 transition">
            <Lock className="w-12 h-12 text-red-400 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Role-Based Access</h3>
            <p className="text-slate-400">Admin dashboard for store owners. Full control over users, permissions, and operations</p>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-500 transition">
            <MessageCircle className="w-12 h-12 text-cyan-400 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">Open Source</h3>
            <p className="text-slate-400">Community-driven development. Contribute, customize, and deploy with total transparency</p>
          </div>
        </div>

        {/* Donation Section - Subtle */}
        <div className="bg-gradient-to-r from-slate-800/50 to-slate-700/50 border border-slate-700 rounded-lg p-8 mb-20">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-white mb-3">💝 Support Sunmart POS</h3>
              <p className="text-slate-300 mb-4">
                Sunmart POS is <span className="font-semibold text-green-400">completely free forever</span>. However, hosting and development costs money. If you'd like to keep this service running, consider a small donation.
              </p>
              <p className="text-sm text-slate-400">Your support helps us:</p>
              <ul className="text-sm text-slate-400 mt-2 space-y-1">
                <li>✓ Maintain secure servers and backups</li>
                <li>✓ Add new features and improvements</li>
                <li>✓ Provide better support and documentation</li>
              </ul>
            </div>

            <div className="flex flex-col items-center gap-4">
              <div className="bg-white p-4 rounded-lg">
                <img
                  src="/media/MaeManee_1763635332821.jpg"
                  alt="Prompt Pay QR Code"
                  className="w-48 h-48 object-contain"
                  onError={(e) => {
                    e.currentTarget.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect fill="%23f0f0f0" width="200" height="200"/><text x="100" y="100" text-anchor="middle" dy=".3em" font-size="12" fill="%23999">QR Code</text></svg>';
                  }}
                />
              </div>
              <p className="text-center text-sm text-slate-400">
                <QrCode className="w-4 h-4 inline mr-1" />
                Scan to donate via Prompt Pay
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="border-t border-slate-700 pt-12 pb-8 text-center text-slate-400">
          <div className="mb-6">
            <h4 className="text-white font-semibold mb-2">Sunmart Online Thailand</h4>
            <p>199 Mung, Udon Thani 41000, Thailand</p>
            <p>Email: suwattchen@gmail.com | Phone: +66 81 240 1237</p>
          </div>
          <p className="text-sm">
            © 2025 Sunmart POS. Open source, forever free for Thai businesses.
          </p>
          <p className="text-xs mt-4 text-slate-500">
            Made with ❤️ by Suwattchen | PostgreSQL 17 | React 18 | TypeScript
          </p>
        </footer>
      </div>

      {/* Structured Data for SEO */}
      <script type="application/ld+json">
        {JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'SoftwareApplication',
          name: 'Sunmart POS',
          description: 'Free multi-tenant point of sale system for Thai businesses',
          url: 'https://sunmart-pos.com',
          applicationCategory: 'BusinessApplication',
          operatingSystem: 'Web',
          offers: {
            '@type': 'Offer',
            price: '0',
            priceCurrency: 'THB',
          },
          provider: {
            '@type': 'Organization',
            name: 'Sunmart Online Thailand',
            address: '199 Mung, Udon Thani 41000, Thailand',
            email: 'suwattchen@gmail.com',
            telephone: '+66-81-240-1237',
          },
          aggregateRating: {
            '@type': 'AggregateRating',
            ratingValue: '4.8',
            ratingCount: '150',
          },
        })}
      </script>
    </div>
  );
}
