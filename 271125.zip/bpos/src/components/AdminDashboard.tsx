import { useState, useEffect } from 'react';
import {
  Building2,
  Users,
  TrendingUp,
  Lock,
  Unlock,
  Trash2,
  Eye,
  Plus,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  AlertCircle,
  CheckCircle,
  Clock,
} from 'lucide-react';
import { api } from '../lib/api';

interface Tenant {
  tenant_id: string;
  database_name: string;
  status: 'active' | 'suspended' | 'deleted';
  created_at: string;
  updated_at: string;
}

interface TenantSubscription {
  tenant_id: string;
  plan_name: 'basic' | 'professional' | 'enterprise';
  status: 'trial' | 'active' | 'suspended' | 'cancelled';
  started_at: string;
  renews_at?: string;
}

interface AdminStats {
  total_tenants: number;
  active_tenants: number;
  suspended_tenants: number;
  monthly_revenue: number;
  total_users: number;
  total_transactions: number;
}

export function AdminDashboard() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [subscriptions, setSubscriptions] = useState<Map<string, TenantSubscription>>(new Map());
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'suspended'>('all');
  const [selectedTenant, setSelectedTenant] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Load data
  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [tenantsData, statsData] = await Promise.all([
        api.get('/admin/tenants'),
        api.get('/admin/stats'),
      ]);

      setTenants(tenantsData.data || []);
      setStats(statsData.data || null);

      // Load subscriptions for each tenant
      if (tenantsData.data) {
        const subsMap = new Map();
        for (const tenant of tenantsData.data) {
          try {
            const sub = await api.get(`/admin/tenants/${tenant.tenant_id}/subscription`);
            subsMap.set(tenant.tenant_id, sub.data);
          } catch (err) {
            console.error(`Failed to load subscription for ${tenant.tenant_id}`);
          }
        }
        setSubscriptions(subsMap);
      }
    } catch (error) {
      console.error('Failed to load admin dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSuspend = async (tenantId: string) => {
    if (!window.confirm('Are you sure you want to suspend this tenant?')) {
      return;
    }

    try {
      setActionLoading(tenantId);
      await api.post(`/admin/tenants/${tenantId}/suspend`);
      setTenants(tenants.map(t => 
        t.tenant_id === tenantId ? { ...t, status: 'suspended' } : t
      ));
    } catch (error) {
      console.error('Failed to suspend tenant:', error);
    } finally {
      setActionLoading(null);
    }
  };

  const handleActivate = async (tenantId: string) => {
    try {
      setActionLoading(tenantId);
      await api.post(`/admin/tenants/${tenantId}/activate`);
      setTenants(tenants.map(t =>
        t.tenant_id === tenantId ? { ...t, status: 'active' } : t
      ));
    } catch (error) {
      console.error('Failed to activate tenant:', error);
    } finally {
      setActionLoading(null);
    }
  };

  const handleDelete = async (tenantId: string) => {
    if (!window.confirm('Are you sure? This will permanently delete all tenant data!')) {
      return;
    }

    try {
      setActionLoading(tenantId);
      await api.delete(`/admin/tenants/${tenantId}`);
      setTenants(tenants.filter(t => t.tenant_id !== tenantId));
    } catch (error) {
      console.error('Failed to delete tenant:', error);
    } finally {
      setActionLoading(null);
    }
  };

  // Filter tenants
  let filteredTenants = tenants;
  if (filterStatus !== 'all') {
    filteredTenants = filteredTenants.filter(t => t.status === filterStatus);
  }
  if (searchTerm) {
    filteredTenants = filteredTenants.filter(t =>
      t.database_name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-50 text-green-700 border-green-200';
      case 'suspended':
        return 'bg-orange-50 text-orange-700 border-orange-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="w-4 h-4" />;
      case 'suspended':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'enterprise':
        return 'bg-purple-100 text-purple-800';
      case 'professional':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-slate-500">Loading admin dashboard...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Admin Dashboard</h1>
          <p className="text-slate-500 mt-1">Manage all tenants and subscriptions</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Plus className="w-4 h-4" />
          Add Tenant
        </button>
      </div>

      {/* Stats Grid */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm">Total Tenants</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{stats.total_tenants}</p>
              </div>
              <Building2 className="w-8 h-8 text-blue-500 opacity-20" />
            </div>
            <p className="text-xs text-green-600 mt-3 flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" />
              {stats.active_tenants} active
            </p>
          </div>

          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm">Total Users</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{stats.total_users}</p>
              </div>
              <Users className="w-8 h-8 text-green-500 opacity-20" />
            </div>
            <p className="text-xs text-slate-500 mt-3">Across all tenants</p>
          </div>

          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm">Monthly Revenue</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">
                  ฿{stats.monthly_revenue.toLocaleString()}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-500 opacity-20" />
            </div>
            <p className="text-xs text-green-600 mt-3 flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" />
              Growth
            </p>
          </div>

          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm">Total Transactions</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">
                  {stats.total_transactions.toLocaleString()}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-orange-500 opacity-20" />
            </div>
            <p className="text-xs text-slate-500 mt-3">All tenants combined</p>
          </div>
        </div>
      )}

      {/* Filters & Search */}
      <div className="bg-white rounded-lg border border-slate-200 p-4 flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search tenants..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value as any)}
          className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Status</option>
          <option value="active">Active Only</option>
          <option value="suspended">Suspended Only</option>
        </select>
      </div>

      {/* Tenants Table */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-900">Database</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-900">Plan</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-900">Status</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-900">Subscription</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-900">Created</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredTenants.map((tenant) => {
                const subscription = subscriptions.get(tenant.tenant_id);
                const isLoading = actionLoading === tenant.tenant_id;

                return (
                  <tr key={tenant.tenant_id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-slate-900">
                      {tenant.database_name}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {subscription && (
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${getPlanColor(subscription.plan_name)}`}>
                          {subscription.plan_name}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <div className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-lg border ${getStatusColor(tenant.status)}`}>
                        {getStatusIcon(tenant.status)}
                        <span className="capitalize">{tenant.status}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {subscription && (
                        <div>
                          <p className="text-slate-900 font-medium capitalize">{subscription.status}</p>
                          {subscription.renews_at && (
                            <p className="text-xs text-slate-500">
                              Renews {new Date(subscription.renews_at).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {new Date(tenant.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button
                          disabled={isLoading}
                          className="p-2 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50"
                          title="View details"
                        >
                          <Eye className="w-4 h-4 text-slate-600" />
                        </button>

                        {tenant.status === 'active' ? (
                          <button
                            onClick={() => handleSuspend(tenant.tenant_id)}
                            disabled={isLoading}
                            className="p-2 hover:bg-orange-50 text-orange-600 rounded-lg transition-colors disabled:opacity-50"
                            title="Suspend tenant"
                          >
                            <Lock className="w-4 h-4" />
                          </button>
                        ) : (
                          <button
                            onClick={() => handleActivate(tenant.tenant_id)}
                            disabled={isLoading}
                            className="p-2 hover:bg-green-50 text-green-600 rounded-lg transition-colors disabled:opacity-50"
                            title="Activate tenant"
                          >
                            <Unlock className="w-4 h-4" />
                          </button>
                        )}

                        <button
                          onClick={() => handleDelete(tenant.tenant_id)}
                          disabled={isLoading}
                          className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors disabled:opacity-50"
                          title="Delete tenant"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredTenants.length === 0 && (
          <div className="text-center py-12">
            <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500">No tenants found</p>
          </div>
        )}
      </div>
    </div>
  );
}
